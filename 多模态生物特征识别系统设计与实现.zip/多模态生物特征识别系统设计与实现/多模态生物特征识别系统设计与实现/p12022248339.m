function varargout = p12022248339(varargin)

gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @p12022248339_OpeningFcn, ...
                   'gui_OutputFcn',  @p12022248339_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
end
%% ================== 系统初始化函数 ===================
function p12022248339_OpeningFcn(hObject, ~, handles, varargin)
handles.output = hObject;
initializeSystem(hObject, handles);
end
%% ===初始化字段必须保留====
function initializeSystem(hObject, handles)

handles.isCameraRunning = false;
handles.currentFace = [];
handles.currentFinger = [];
handles.log_messages = {}; % 初始化日志
handles.currentFaceFilename = ''; % 新增：初始化用于存储指纹1文件名的字段
handles.currentFingerFilename = ''; % 新增：初始化用于存储指纹2文件名的字段
 


% 界面控件初始化
initAxes(handles);
set(handles.slider1, 'Min',0, 'Max',100, 'Value',0,...
    'Enable','off', 'SliderStep',[1 10]);
set(handles.popupmenu1, 'String',{'表情识别','指纹识别'});
set(handles.textResult, 'String', "");
 try
        % 检查是否安装了 Webcam 支持包
        if isempty(which('webcam'))

             handles = addLogMessage(handles, '警告: Webcam支持包未安装');
        else
            handles = addLogMessage(handles, '摄像头支持包已安装');
        end
    catch ME
        handles = addLogMessage(handles, ['摄像头初始化错误: ' ME.message]);
    end
% === 新增：加载校徽到 axes4 ===
   try
    % 尝试加载 logo.png（确保文件在MATLAB路径中）
    [logo, ~, alpha] = imread('logo.png');
    axes(handles.axes4);       % 切换到 axes7
    h = image(logo);
    set(h, 'AlphaData', alpha);
    set(handles.axes4, 'Color', 'none', 'Box', 'off');
    axis off;
     % 设置坐标轴位置适应图像
    axis tight;
    axis equal;
    set(handles.axes4, 'Units', 'normalized'); % 确保正常缩放
    catch
    % 如果加载失败显示警告（但不中断程序）
    warning('Logo 图片加载失败，请确保 logo.png 在路径中');
    end
% 硬件初始化
% 添加摄像头相关字段
    handles.cameraObj = [];
    handles.isCameraRunning = false;
handles.speech_enabled = true;

   handles = addLogMessage(handles, '系统初始化完成');
handles.cameraObj = [];
handles.isCameraRunning = false;
handles = addLogMessage(handles, '系统初始化完成，表情识别采用Gabor+PCA+ELM流程');

guidata(hObject, handles);
end

%% ================== 新增：系统重置辅助函数 ===================
function handles = resetSystem(handles)
% resetSystem: 重置系统界面和内部状态到初始值
% 确保handles结构体在重置后被返回，以便更新GUIDATA

    handles.currentFace = [];
    handles.currentFinger = [];
    handles.log_messages = {}; % 清空日志
    handles.currentFaceFilename = '';
    handles.currentFingerFilename = '';
    handles.isCameraRunning = false; % 标记为非实时图片

    % 重置 Axes，清除内容，设置显示模式，并添加下方的文本标题
    for ax = [handles.axes1, handles.axes2, handles.axes3]
        cla(ax); % 清除轴内容
        axis(ax, 'image'); % 设置图像模式
        set(ax, ...  % 显式设置关键属性
            'Visible', 'on', ...  % 确保坐标轴整体可见
            'Box', 'on', ...      % 强制开启边框
            'XTick', [], ...     % 隐藏刻度
            'YTick', []);
        title(ax, '');
    end

    % 重新添加 axes1, axes2, axes3 的文本标题
    text('Parent', handles.axes1, 'Units', 'normalized', 'Position', [0.5, -0.1],...
        'String', '人脸图像/指纹图像1', 'HorizontalAlignment', 'center', 'FontSize', 10);
    text('Parent', handles.axes2, 'Units', 'normalized', 'Position', [0.5, -0.1],...
        'String', '指纹图像2', 'HorizontalAlignment', 'center', 'FontSize', 10);
    text('Parent', handles.axes3, 'Units', 'normalized', 'Position', [0.5, -0.1],...
        'String', '识别结果', 'HorizontalAlignment', 'center', 'FontSize', 10);

    set(handles.slider1, 'Value',0);
    set(handles.text5, 'String','0%');
    set(handles.slider1, 'BackgroundColor', get(0, 'defaultUicontrolBackgroundColor')); % 重置进度条颜色
    set(handles.textResult, 'String', ""); % 清除 textResult 上的文本

    handles = addLogMessage(handles, '系统状态已重置。'); % 记录日志
    drawnow; % 强制刷新GUI，确保边框等元素正确显示
end

%% Gabor滤波器生成
function gaborBank = createGaborBank(numScales, numOrientations)
    lambda = 2.^(0:numScales-1)*4;
    theta = linspace(0, 180-180/numOrientations, numOrientations);
    gaborBank = cell(numScales, numOrientations);
    for s = 1:numScales
        for o = 1:numOrientations
            sigma = lambda(s)*1.5/pi;
            gamma = 0.5;
            [x,y] = meshgrid(-round(3*sigma):round(3*sigma));
            xTheta = x*cosd(theta(o)) + y*sind(theta(o));
            yTheta = -x*sind(theta(o)) + y*cosd(theta(o));
            gb = exp(-0.5*(xTheta.^2 + (gamma*yTheta).^2)/sigma^2) ...
                .* cos(2*pi*xTheta/lambda(s));
            gb = gb - mean(gb(:));
            gb = gb / norm(gb(:));
            gaborBank{s,o} = gb;
        end
    end
end
%% ================== 主界面输出 ===================
function varargout = p12022248339_OutputFcn(~, ~, handles)
varargout{1} = handles.output;
end

%% ================== 界面工具函数 ===================
function initAxes(handles)
% 初始化 Axes，清除内容，设置显示模式，并添加下方的文本标题
for ax = [handles.axes1, handles.axes2, handles.axes3, handles.axes4]
    cla(ax);
    axis(ax, 'image');
    box(ax, 'on');
    ax.XTick = [];
    ax.YTick = [];
    title(ax, '');
end

% 添加标题（axes4不加标题）
text('Parent', handles.axes1, 'Units', 'normalized', 'Position', [0.5, -0.1],...
    'String', '人脸图像/指纹图像1', 'HorizontalAlignment', 'center', 'FontSize', 10);
text('Parent', handles.axes2, 'Units', 'normalized', 'Position', [0.5, -0.1],...
    'String', '指纹图像2', 'HorizontalAlignment', 'center', 'FontSize', 10);
text('Parent', handles.axes3, 'Units', 'normalized', 'Position', [0.5, -0.1],...
    'String', '识别结果', 'HorizontalAlignment', 'center', 'FontSize', 10);
end

%%\
%---上传指纹图像1 (修改 pushbutton1_Callback)
function pushbutton1_Callback(hObject, ~, handles)
% 假设这个按钮用于上传指纹图像1到 axes1
[file, path] = uigetfile({'*.tiff;*.jpg;*.tif;*.png;*.gif','指纹图像1'});
if ~isequal(file,0)
    try
        img=imread(fullfile(path, file));
        displayImage(handles.axes1, img); % 显示在 axes1
        handles.currentFace = img; % === 将图片存储到 handles.currentFace ===
        handles.currentFaceFilename = file; % 直接存储 uigetfile 返回值
        guidata(hObject, handles);

        % === 提醒用户切换到指纹识别模式 (保留您的代码) ===
        current_mode_value = get(handles.popupmenu1, 'Value');
        if current_mode_value == 1 % 如果当前是表情识别模式 (Value 1)
            helpdlg('您已载入指纹图像1。请从下拉菜单中选择"指纹识别"模式以进行指纹识别或多模态识别。', '模式切换提醒');
        end
        % === 新增结束 ===

        % 新增：语音说明：指纹图像1已上传，请进行下一步操作
        if handles.speech_enabled && ispc
            try
                Speech = actxserver('SAPI.SpVoice');
                 Speech.Rate = 3; % 设置语速为 3
                Speech.Speak('指纹图像一已成功上传，请继续上传指纹图像二或点击开始识别。');
                handles = addLogMessage(handles, sprintf('语音提示: 指纹图像一已成功上传: %s，请进行下一步操作。', file));
            catch ME_speech
                handles = addLogMessage(handles, sprintf('语音播报错误: %s', ME_speech.message));
            end
        end

    catch ME % 捕获加载或预处理指纹图像时的错误
        errordlg(sprintf('指纹图像1加载或预处理失败\n错误信息: %s', ME.message),'文件错误');
    end
end
end
%% ----- 文件操作回调 -----
function pushbutton3_Callback(hObject, ~, handles)
[file, path] = uigetfile({'*.tiff;*.jpg;*.tif;*.png;*.gif','All Image Files';'*.*','All Files' },'载入图像','./Test/im1.tiff');
if ~isequal(file,0)
    try
        img = imread(fullfile(path, file));
        displayImage(handles.axes1, img); % displayImage 会在下方添加标题
        handles.currentFace = img;
        guidata(hObject, handles);

        % 新增：语音说明：人脸图像已上传，请进行下一步操作
        if handles.speech_enabled && ispc
            try
                Speech = actxserver('SAPI.SpVoice');
                 Speech.Rate = 3; % 设置语速为 3
                Speech.Speak('人脸图像已成功上传，请点击开始识别。');
                handles = addLogMessage(handles, sprintf('语音提示: 人脸图像已成功上传: %s，请进行下一步操作。', file));
            catch ME_speech
                handles = addLogMessage(handles, sprintf('语音播报错误: %s', ME_speech.message));
            end
        end

    catch
        errordlg('人脸图像加载失败','文件错误');
    end
end

end
%%
%---上传指纹图像2 (pushbutton4_Callback 代码保持不变，但现在明确其功能)
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    [file, path] = uigetfile({'*.png;*.jpg;*.jpeg;*.gif;*.tif;*.tiff', '图像文件 (*.png, *.jpg, *.jpeg, *.gif, *.tif, *.tiff)';
                              '*.tiff;*.jpg;*.tif;*.png;*.gif','指纹图像2'});
if ~isequal(file,0)
    try
        % 如果需要对指纹图像2进行预处理，在这里调用 preprocessFinger
        % img = preprocessFinger(imread(fullfile(path, file)));
        img=imread(fullfile(path, file)); % === 加载图片 ===
        displayImage(handles.axes2, img); % 显示在 axes2
        handles.currentFinger = img; % === 将图片存储到 handles.currentFinger ===
        handles.currentFingerFilename = file; % 直接存储 uigetfile 返回值
        guidata(hObject, handles);

        % === 提醒用户切换到指纹识别模式 (保留您的代码) ===
        current_mode_value = get(handles.popupmenu1, 'Value');
        if current_mode_value == 1 % 如果当前是表情识别模式 (Value 1)
            helpdlg('您已载入指纹图像2。请从下拉菜单中选择"指纹识别"模式以进行指纹识别或多模态识别。', '模式切换提醒');
        end
        % === 新增结束 ===

        % 新增：语音说明：指纹图像2已上传，请进行下一步操作
        if handles.speech_enabled && ispc
            try
                Speech = actxserver('SAPI.SpVoice');
                 Speech.Rate = 3; % 设置语速为 3
                Speech.Speak('指纹图像二已成功上传，请点击开始识别。');
                handles = addLogMessage(handles, sprintf('语音提示: 指纹图像二已成功上传: %s，请进行下一步操作。', file));
            catch ME_speech
                handles = addLogMessage(handles, sprintf('语音播报错误: %s', ME_speech.message));
            end
        end

    catch ME % 捕获加载或预处理指纹图像时的错误
        errordlg(sprintf('指纹图像2加载或预处理失败\n错误信息: %s', ME.message),'文件错误');
    end
end
end

%% ================== 开始识别回调（最终修正版） ===================
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    % 清除之前的检测结果
    handles = guidata(hObject);
    try
        % 字段存在性检查（关键修复）
        if ~isfield(handles, 'currentFace')
            handles.currentFace = [];
            guidata(hObject, handles);
        end
        if ~isfield(handles, 'currentFinger')
            handles.currentFinger = [];
            guidata(hObject, handles);
        end

        mode = get(handles.popupmenu1,'Value');

        % 输入验证逻辑（根据模式定制提示）
        if mode == 1 % 表情识别模式
            if isempty(handles.currentFace)
                errordlg({'请先执行以下操作：',...
                          '1. 点击"上传人脸图像"按钮',...
                          '2. 或使用"实时采集"功能'},...
                         '人脸图像缺失');
                return;
            end
        else % 生物认证模式
            missingFields = {};
           if isempty(handles.currentFace)
                missingFields{end+1} = '指纹图像1'; % 提示缺少 指纹图像1
            end
            if isempty(handles.currentFinger)
                missingFields{end+1} = '指纹信息2'; % 提示缺少 指纹信息2
            end

            if ~isempty(missingFields)
                errordlg({'缺少以下必要信息：',...
                          strjoin(missingFields, ' 和 ')},...
                         '输入不完整');
                return;
            end
        end

        % 原有识别逻辑
        if mode == 1
            processEmotion(hObject,handles);
        else
            processBiometrics(handles);
        end

    catch ME
        errordlg(['识别过程出错: ' ME.message],'系统错误');
    end
end
%%
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    handles = guidata(hObject);
    if ~isfield(handles, 'currentFace') || ~isfield(handles, 'currentFinger') ...
        || isempty(handles.currentFace) || isempty(handles.currentFinger)
    errordlg('请先上传人脸图片和指纹图片','保存错误');
    return;
end
msgbox('数据保存成功！','保存成功');
guidata(hObject, handles);

% 新增：语音说明：数据保存成功
    if handles.speech_enabled && ispc
        try
            Speech = actxserver('SAPI.SpVoice');
             Speech.Rate = 3; % 设置语速为 3
            Speech.Speak('数据已成功保存。');
            handles = addLogMessage(handles, '语音提示: 数据已成功保存。');
        catch ME_speech
            handles = addLogMessage(handles, sprintf('语音播报错误: %s', ME_speech.message));
        end
    end

end
%%
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    handles = resetSystem(handles); % 调用重置函数
    guidata(hObject, handles);

    % 新增：语音说明：系统已重置
    if handles.speech_enabled && ispc
        try
            Speech = actxserver('SAPI.SpVoice');
             Speech.Rate = 3; % 设置语速为 3
            Speech.Speak('系统已重置成功。');
            handles = addLogMessage(handles, '语音提示: 系统已重置成功。');
        catch ME_speech
            handles = addLogMessage(handles, sprintf('语音播报错误: %s', ME_speech.message));
        end
    end

end

%%
function pushbutton11_Callback(hObject, ~, handles) % 修复函数签名
% hObject    handle to pushbutton11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

selection = questdlg('确认退出系统？','退出确认','是','否','是');
if strcmp(selection,'是')
        % 新增：语音说明：已退出系统 (移到确认后，窗口关闭前)
        if handles.speech_enabled && ispc
            try
                Speech = actxserver('SAPI.SpVoice');
                 Speech.Rate = 3; % 设置语速为 3
                Speech.Speak('系统已安全退出。');
                handles = addLogMessage(handles, '语音提示: 系统已安全退出。');
            catch ME_speech
                handles = addLogMessage(handles, sprintf('语音播报错误: %s', ME_speech.message));
            end
        end
        % 释放摄像头资源
        if isfield(handles, 'cameraObj') && ~isempty(handles.cameraObj)
            clear handles.cameraObj;
        end
        close(gcf);
end
end
%% ================== 处理函数 ===================
function processEmotion(hObject,handles)
% 将 img 传递给 baidu_face_expression 函数
if isfield(handles, 'isCameraRunning') && handles.isCameraRunning
    img = handles.currentFace;
    % 调用修改后的 baidu_face_expression 函数，接收完整的API响应结构体
    api_response_struct = baidu_face_expression(img, handles);

    % 初始化默认值
    str = '未检测到人脸或识别失败';
    percent = 0;
    face_data = []; % 用于存储第一张人脸的详细数据

    % 检查API响应是否有错误
    if isfield(api_response_struct, 'error_code') && api_response_struct.error_code ~= 0
        str = sprintf('API错误: %s', api_response_struct.error_msg);
        handles = addLogMessage(handles, str);
        if handles.speech_enabled && ispc
             Speech = actxserver('SAPI.SpVoice');
              Speech.Rate = 3; % 设置语速为 3
             Speech.Speak(sprintf('人脸识别API错误，%s', str));
        end
    elseif isfield(api_response_struct, 'result') && isfield(api_response_struct.result, 'face_num') && api_response_struct.result.face_num > 0
        % 检测到人脸
        face_list = api_response_struct.result.face_list;
        face_data = face_list(1); % 取第一张人脸数据

        % 获取表情信息
        if isfield(face_data, 'expression') && isfield(face_data.expression, 'type')
            expr_type = face_data.expression.type;
            prob_expression = face_data.expression.probability; % 获取表情置信度

            % 映射为中文
            expr_map = containers.Map(...
                {'none', 'smile', 'laugh', 'anger', 'sad', 'disgust', 'fear', 'surprise', 'neutral'},...
                {'无表情', '微笑', '大笑', '愤怒', '悲伤', '厌恶', '恐惧', '惊讶', '平静'});
            if isKey(expr_map, expr_type)
                str = expr_map(expr_type);
            else
                str = '未知表情';
            end
            percent = prob_expression * 100; % 表情置信度百分比
        else
            str = '未检测到表情信息';
        end

        % 添加语音播报功能
        if handles.speech_enabled && ispc
            try
                Speech = actxserver('SAPI.SpVoice');
                 Speech.Rate = 3; % 设置语速为 3
                % 构建播报文本
                speech_text = sprintf('检测到人脸，表情是%s，置信度百分之%.1f。', str, percent);
                % 如果有性别信息，也播报
                if isfield(face_data, 'gender') && isfield(face_data.gender, 'type')
                    gender_type = face_data.gender.type;
                    if strcmp(gender_type, 'male')
                         speech_text = [speech_text, '性别是男性。'];
                    elseif strcmp(gender_type, 'female')
                         speech_text = [speech_text, '性别是女性。'];
                    end
                end
                Speech.Speak(speech_text);
            catch ME_speech
                handles = addLogMessage(handles, sprintf('语音播报错误: %s', ME_speech.message));
            end
        end

        % 弹窗显示详细信息 (需要新增 displayFaceDetailsDialog 函数)
        displayFaceDetailsDialog(handles.currentFace, face_data); % 传递原始图像和人脸数据

    else
        % 未检测到人脸
        str = '未检测到人脸';
        percent = 0;
        handles = addLogMessage(handles, str);
        if handles.speech_enabled && ispc
             Speech = actxserver('SAPI.SpVoice');
              Speech.Rate = 3; % 设置语速为 3
             Speech.Speak('未检测到人脸。');
        end
    end

    set(handles.textResult, 'String', str);
    set(handles.slider1, 'Value', percent);
    set(handles.text5, 'String', sprintf('%.1f%%', percent));

    % 进度条颜色优化 (保持不变)
    if percent > 80
        set(handles.slider1, 'BackgroundColor', [0.2 0.8 0.2]); % 绿色
    elseif percent > 60
        set(handles.slider1, 'BackgroundColor', [1.0 0.8 0.0]); % 黄色
    else
        set(handles.slider1, 'BackgroundColor', [1.0 0.2 0.2]); % 红色
    end

    updateResultDisplay(handles, percent / 100); % 传递0~1的置信度
    handles = addLogMessage(handles, sprintf('百度AI识别表情: %s, 置信度: %.2f%%', str, percent));
    guidata(hObject, handles);
    return;
end


% 1. 输入检查和图像预处理
    % 检查 handles.currentFace 是否有效
    if isequal(handles.currentFace, 0) || isempty(handles.currentFace)
        errordlg('未捕获到人脸图像。','处理错误');
        cla(handles.axes3);
        title(handles.axes3, '识别结果');
        set(handles.textResult, 'String', "");
        set(handles.slider1, 'Value', 0);
        set(handles.text5, 'String', "0.0%");
        updateResultDisplay(handles, 0); % Update display with 0 confidence
        guidata(hObject, handles);
        return; % 结束函数执行
    end

    img = handles.currentFace;
     % 转换为灰度图 (如果不是)
    if ndims(img) == 3
        img_gray = rgb2gray(img);
    else
        img_gray = img;
    end
    % 统一预处理尺寸，用于 Gabor 和可能的图像匹配（虽然这里不直接用于匹配，但特征提取尺寸需一致）
    img_resized = imresize(img_gray, [50 50], 'bilinear');

% 2. Gabor特征提取
    % 使用预处理后的图像进行 Gabor 提取
    % 确保 gaborfilter 函数在 MATLAB 搜索路径中
    try
        [~,gabout] = gaborfilter(double(img_resized), 2, 4, 16, pi/3); % Gaborfilter可能需要double类型的输入
        imshow(gabout, [], 'Parent', handles.axes3); % 显示 Gabor 特征图
        handles.GaborFeature = gabout; % 存储 Gabor 特征供后续使用
    catch ME
        errordlg(sprintf('Gabor特征提取失败\n错误信息: %s', ME.message),'特征提取错误');
         cla(handles.axes3);
        title(handles.axes3, 'Gabor特征 (错误)');
        set(handles.textResult, 'String', "");
        set(handles.slider1, 'Value', 0);
         set(handles.text5, 'String', "0.0%");
        updateResultDisplay(handles, 0);
        guidata(hObject, handles);
        return;
    end


% 3. PCA 降维
    gab_flat = gabout(:)'; % 展平 Gabor 特征 (1 x 50*50 = 1 x 2500)

    try
        % 加载 PCA 模型文件 model.mat，包含 base 和 samplemean
        % 确保 model.mat 包含基于 Gabor 特征训练的 PCA 模型
        model_filepath = fullfile(pwd, 'model.mat');
        if ~exist(model_filepath, 'file')
             error('PCA模型文件 model.mat 不存在。请先进行PCA训练。');
        end
        load(model_filepath, 'base', 'samplemean');

        % 检查加载的数据维度是否与 Gabor 特征匹配 (训练 PCA 时使用的 Gabor 特征维度)
        if size(gab_flat, 2) ~= size(samplemean, 2)
             error('Gabor特征维度(%d)与PCA模型中samplemean维度(%d)不匹配。请确保PCA模型是基于2500维Gabor特征训练的。', size(gab_flat, 2), size(samplemean, 2));
        end
         if size(gab_flat, 2) ~= size(base, 1)
              error('Gabor特征维度(%d)与PCA模型中base的行数(%d)不匹配。请确保PCA模型是基于2500维Gabor特征训练的。', size(gab_flat, 2), size(base, 1));
         end


        % 对特征进行中心化 (减去均值)，确保 samplemean 是double类型
        b_centered = double(gab_flat) - double(samplemean);
        % 投影到 PCA 空间
        tcoor_pca = b_centered * base;              % (1 x 2500) * (2500 x N_pca) => (1 x N_pca)
        % N_pca 是 base 的列数，也是 PCA 降维后的维数，需要与 ELM 输入特征数量一致 (通常是 196)
        dim_info = sprintf('输入图像 Gabor 特征降维后维度: [%d, %d]\n', size(tcoor_pca, 1), size(tcoor_pca, 2));
         handles = addLogMessage(handles, dim_info);
        guidata(hObject, handles);

    catch ME
        errordlg(sprintf('加载PCA模型或PCA计算失败\n错误信息: %s', ME.message),'PCA错误');
        % 清理可能的残余显示和结果
        cla(handles.axes3);
        title(handles.axes3, 'Gabor特征 (错误)');
        set(handles.textResult, 'String', "");
        set(handles.slider1, 'Value', 0);
         set(handles.text5, 'String', "0.0%");
        updateResultDisplay(handles, 0);
        guidata(hObject, handles);
        return; % 结束函数执行
    end

    % 存储 PCA 降维后的特征供 ELM 和图像匹配使用
    handles.PCAFeature = tcoor_pca;

% 4. ELM 和图像相似度匹配预测
    % ELM 输入数据格式: [标签(占位，测试时通常为0), 特征向量]
    % 我们的 PCA 特征是 handles.PCAFeature (1 x N_pca)
    elm_input_data = [0, handles.PCAFeature]; % 构建 ELM 输入矩阵 (1 x 1+N_pca)

    % 调用 elm_predict 函数
    % 注意：这里不再向 elm_predict 传递原始图像 dt 进行二次特征提取
    try
        % elm_predict 现在只接收包含 PCA 特征的 test_data 参数
        [testing_time, elm_predicted_label, elm_confidence, image_matched_label] = elm_predict(elm_input_data);
        % elm_predict 函数签名需要修改以只接收 test_data

        % 确保预测结果是单个值（因为我们一次处理一个样本）
        if length(elm_predicted_label) > 1
             warning('elm_predict 返回了多个ELM预测标签，只取第一个。');
             elm_predicted_label = elm_predicted_label(1);
        end
        if length(elm_confidence) > 1
            warning('elm_predict 返回了多个ELM置信度，只取第一个。');
            elm_confidence = elm_confidence(1);
        end
        % image_matched_label 应该已经是单个值或 NaN

    catch ME
         errordlg(sprintf('ELM预测或图像匹配失败\n错误信息: %s', ME.message),'预测错误');
         % 清理结果显示
         set(handles.textResult, 'String', "预测失败");
         set(handles.slider1, 'Value', 0);
         set(handles.text5, 'String', "0.0%");
         updateResultDisplay(handles, 0);
         guidata(hObject, handles);
         return; % 结束函数执行
    end


% 5. 融合决策和结果显示
    final_predicted_label = NaN;
    fusion_confidence = 0; % 初始化融合置信度

    % --- 在这里实现你的融合逻辑 ---
    % 示例融合策略：优先使用ELM高置信度结果，否则考虑图像匹配
    confidence_threshold = 0.6; % 可以调整的置信度阈值，略微降低试试

    dim_info = sprintf('ELM预测结果: 标签 %f, 置信度 %f\n', elm_predicted_label, elm_confidence);
     handles = addLogMessage(handles, dim_info);
        guidata(hObject, handles);
    dim_info = sprintf('图像匹配结果: 标签 %f\n', image_matched_label);
     handles = addLogMessage(handles, dim_info);
        guidata(hObject, handles);



    if ~isnan(elm_predicted_label) % 如果ELM有有效预测
        % 检查 ELM 置信度是否有效且高于阈值
        if ~isnan(elm_confidence) && elm_confidence >= confidence_threshold
            final_predicted_label = elm_predicted_label;
            fusion_confidence = elm_confidence;
            dim_info = sprintf('采用ELM高置信度结果: 标签 %f, 置信度 %.2f\n', final_predicted_label, fusion_confidence);
             handles = addLogMessage(handles, dim_info);
        guidata(hObject, handles);
        else
            % ELM 置信度不高或为NaN，考虑图像匹配结果
            if ~isnan(image_matched_label)
                 % 图像匹配结果有效，采纳图像匹配结果
                 final_predicted_label = image_matched_label;
                 % 图像匹配没有直接的概率置信度，这里简单使用 ELM 置信度作为参考，或设为 NaN
                 fusion_confidence = elm_confidence; % 仍然显示ELM的置信度作为参考
                 dim_info = sprintf('ELM置信度低(%.2f)/无效，采用图像匹配结果: 标签 %f\n', elm_confidence, final_predicted_label);
                  handles = addLogMessage(handles, dim_info);
        guidata(hObject, handles);

            else
                 % ELM置信度低/无效，图像匹配无效，只能依赖ELM结果（即使置信度低）
                 final_predicted_label = elm_predicted_label;
                 fusion_confidence = elm_confidence;
                 dim_info = sprintf('ELM置信度低(%.2f)/无效，图像匹配无效，采用ELM结果: 标签 %f\n', fusion_confidence, final_predicted_label);
                  handles = addLogMessage(handles, dim_info);
        guidata(hObject, handles);
            end
        end
    elseif ~isnan(image_matched_label) % 如果ELM预测无效但图像匹配有效
        final_predicted_label = image_matched_label;
        fusion_confidence = NaN; % 图像匹配没有ELM那样的置信度，设为NaN
        dim_info = sprintf('ELM预测无效，采用图像匹配结果: 标签 %f\n', final_predicted_label);
         handles = addLogMessage(handles, dim_info);
        guidata(hObject, handles);
    else
        % 两者都无效
        final_predicted_label = NaN;
        fusion_confidence = 0;
        dim_info = sprintf('ELM预测和图像匹配均无效。\n');
    end


    % 结果映射
    emotion_map = {
        1, '平静'; % Neutral
        2, '高兴'; % Happy
        3, '悲伤'; % Sad
        4, '惊讶'; % Surprise
        5, '愤怒'; % Anger
        6, '厌恶'; % Disgust
        7, '恐惧'}; % Fear
     % 请确保这里的标签序号(1-7)与您的 ELM 训练标签以及 S.mat 文件名中的前缀映射一致！

    if ~isnan(final_predicted_label) && isnumeric(final_predicted_label) && final_predicted_label >= 1 && final_predicted_label <= length(emotion_map) && mod(final_predicted_label,1) == 0 % Ensure it's a valid integer label
        % Convert label (which might be double) to integer index for emotion_map
        label_idx = round(final_predicted_label);
        if label_idx >= 1 && label_idx <= length(emotion_map)
             str = emotion_map{label_idx, 2};
        else
             str = '未知情绪 (标签超出范围)';
             warning('最终预测标签 %f 转换为索引 %d 后超出情绪映射范围。', final_predicted_label, label_idx);
        end


         % 显示融合置信度，如果为NaN则显示一个默认值
         if isnan(fusion_confidence)
             confidence_percent = NaN; % 或者显示 "N/A"
         else
            confidence_percent = fusion_confidence * 100;
         end

        set(handles.textResult, 'String', str);
        % 显示置信度 (作为百分比或原始值)
        if isnan(confidence_percent)
             set(handles.text5, 'String', "N/A");
             set(handles.slider1, 'Value', 0); % Slider maybe set to 0 or handle differently for NaN
        else
            % Ensure confidence_percent is within slider range (0-100)
            confidence_percent = max(0, min(100, confidence_percent));
            set(handles.slider1, 'Value', confidence_percent);
            set(handles.text5, 'String', sprintf('%.1f%%', confidence_percent));

            % 根据置信度设置进度条颜色
            if confidence_percent > 80
                set(handles.slider1, 'BackgroundColor', [0.2 0.8 0.2]); % Green
            elseif confidence_percent > 60
                set(handles.slider1, 'BackgroundColor', [1.0 0.8 0.0]); % Yellow
            else
                set(handles.slider1, 'BackgroundColor', [1.0 0.2 0.2]); % Red
            end
        end


    else
        % 预测标签无效或超出范围
        set(handles.textResult, 'String', "未知情绪");
        set(handles.slider1, 'Value', 0);
         set(handles.text5, 'String', "0.0%");
        warning('最终预测标签 %f 无效、非数值或超出情绪映射范围。', final_predicted_label);
    end

    % 更新 GUI 显示（如果需要的话），传递融合置信度（0-1之间）
     updateResultDisplay(handles, fusion_confidence);

    guidata(hObject, handles);

end

%% ================== 新增：显示人脸详细信息弹窗函数 ===================
function displayFaceDetailsDialog(face_img, face_data)
% face_img: 实时采集到的人脸图像
% face_data: 从API获取的单个人脸详细数据结构体

    % 创建一个模态对话框
    d = dialog('Position', [100 100 700 500], 'Name', '人脸识别详细信息', 'WindowStyle', 'modal');

    % 左侧：显示人脸图像
    ax_img = axes('Parent', d, 'Units', 'pixels', 'Position', [30 80 300 300]);
    if ~isempty(face_img)
        imshow(face_img, 'Parent', ax_img);
        title(ax_img, '实时采集人脸');
        axis(ax_img, 'image');
        axis(ax_img, 'off');
    else
        text(0.5, 0.5, '无图像', 'HorizontalAlignment', 'center', 'Parent', ax_img);
        axis(ax_img, 'off');
    end

    % 右侧：显示识别信息
    panel_info = uipanel('Parent', d, 'Units', 'pixels', 'Position', [360 80 300 380], 'Title', '识别信息');

    % 信息显示区域 (使用 uicontrol text 控件，方便换行和格式化)
    info_text = uicontrol('Parent', panel_info, 'Style', 'text', 'Units', 'normalized', ...
                          'Position', [0.05 0.02 0.9 0.95], 'HorizontalAlignment', 'left', ...
                          'FontName', '宋体', 'FontSize', 10, 'Max', 2, 'Min', 0, 'String', ''); % 修改字体和大小

    % 构建显示文本
    display_str = {};
    display_str{end+1} = '-- 基础信息 --';
    if isfield(face_data, 'face_probability')
        display_str{end+1} = sprintf('人脸置信度: %.1f%%', face_data.face_probability * 100);
    end
    if isfield(face_data, 'age')
        display_str{end+1} = sprintf('年龄: %d岁', face_data.age);
    end

    % 强制性别为男性
    display_str{end+1} = '性别: 男性'; % 强制显示男性
    if isfield(face_data, 'gender') && isfield(face_data.gender, 'probability')
        display_str{end+1} = sprintf('  (原始置信度: %.1f%%)', face_data.gender.probability * 100);
    end

    if isfield(face_data, 'race')
        race_map = containers.Map({'yellow', 'white', 'black', 'arabs'}, {'黄种人', '白种人', '黑种人', '阿拉伯人'});
        race_type = face_data.race.type;
        if isKey(race_map, race_type)
            race_type = race_map(race_type);
        end
        display_str{end+1} = sprintf('人种: %s (%.1f%%)', race_type, face_data.race.probability * 100);
    end

    display_str{end+1} = '';
    display_str{end+1} = '-- 表情/情绪 --';
    if isfield(face_data, 'expression')
        expr_map = containers.Map({'none', 'smile', 'laugh', 'anger', 'sad', 'disgust', 'fear', 'surprise', 'neutral'},...
                                {'无表情', '微笑', '大笑', '愤怒', '悲伤', '厌恶', '恐惧', '惊讶', '平静'});
        expr_type = face_data.expression.type;
        if isKey(expr_map, expr_type)
            expr_type = expr_map(expr_type);
        end
        display_str{end+1} = sprintf('表情: %s (%.1f%%)', expr_type, face_data.expression.probability * 100);
    end
    if isfield(face_data, 'emotion')
        emotion_map = containers.Map({'angry', 'disgust', 'fear', 'happy', 'sad', 'surprise', 'neutral', 'pouty', 'grimace'},...
                                 {'愤怒', '厌恶', '恐惧', '高兴', '悲伤', '惊讶', '平静', '撅嘴', '鬼脸'});
        emotion_type = face_data.emotion.type;
        if isKey(emotion_map, emotion_type)
            emotion_type = emotion_map(emotion_type);
        end
        display_str{end+1} = sprintf('情绪: %s (%.1f%%)', emotion_type, face_data.emotion.probability * 100);
    end

    display_str{end+1} = '';
    display_str{end+1} = '-- 穿戴/活体 --';
    if isfield(face_data, 'glasses')
        glasses_map = containers.Map({'none', 'common', 'sun', 'black'}, {'无眼镜', '普通眼镜', '太阳镜', '黑框眼镜'});
        glasses_type = face_data.glasses.type;
        if isKey(glasses_map, glasses_type)
            glasses_type = glasses_map(glasses_type);
        end
        display_str{end+1} = sprintf('眼镜: %s (%.1f%%)', glasses_type, face_data.glasses.probability * 100);
    end
    if isfield(face_data, 'mask')
        mask_map = containers.Map({'0', '1', 'none', 'wear'}, {'无口罩', '佩戴口罩', '无口罩', '佩戴口罩'});
        mask_type = num2str(face_data.mask.type);
        if isKey(mask_map, mask_type)
            mask_type = mask_map(mask_type);
        end
        display_str{end+1} = sprintf('口罩: %s (%.1f%%)', mask_type, face_data.mask.probability * 100);
    end
    if isfield(face_data, 'headwear')
        headwear_map = containers.Map({'0', '1', 'none', 'hat', 'helmet', 'safety_helmet'},...
                                  {'无头饰', '有头饰', '无头饰', '帽子', '头盔', '安全帽'});
        headwear_type = num2str(face_data.headwear.type);
        if isKey(headwear_map, headwear_type)
            headwear_type = headwear_map(headwear_type);
        end
        display_str{end+1} = sprintf('头饰: %s (%.1f%%)', headwear_type, face_data.headwear.probability * 100);
    end
    if isfield(face_data, 'face_type')
        live_map = containers.Map({'LIVE', 'IDPHOTO', 'WATERMARK', 'SCREEN', 'MASK'},...
                                {'真人', '证件照', '带水印照片', '屏幕翻拍', '面具'});
        live_type = face_data.face_type.type;
        if isKey(live_map, live_type)
            live_type = live_map(live_type);
        end
        display_str{end+1} = sprintf('活体检测: %s (%.1f%%)', live_type, face_data.face_type.probability * 100);
    end

    display_str{end+1} = '';
    display_str{end+1} = '-- 质量/其他 --';
    if isfield(face_data, 'quality')
        qual = face_data.quality;
        if isfield(qual, 'completeness')
            display_str{end+1} = sprintf('完整度: %.1f', qual.completeness);
        end
        if isfield(qual, 'illumination')
            display_str{end+1} = sprintf('光照: %.1f', qual.illumination);
        end
        if isfield(qual, 'blur')
            display_str{end+1} = sprintf('模糊度: %.1f', qual.blur);
        end
        if isfield(qual, 'occlusion')
            occ = qual.occlusion;
            occ_info = {};
            if isfield(occ, 'left_eye') && occ.left_eye > 0.5; occ_info{end+1} = '左眼'; end;
            if isfield(occ, 'right_eye') && occ.right_eye > 0.5; occ_info{end+1} = '右眼'; end;
            if isfield(occ, 'nose') && occ.nose > 0.5; occ_info{end+1} = '鼻子'; end;
            if isfield(occ, 'mouth') && occ.mouth > 0.5; occ_info{end+1} = '嘴巴'; end;
            if isfield(occ, 'left_cheek') && occ.left_cheek > 0.5; occ_info{end+1} = '左脸颊'; end;
            if isfield(occ, 'right_cheek') && occ.right_cheek > 0.5; occ_info{end+1} = '右脸颊'; end;
            if isfield(occ, 'chin_contour') && occ.chin_contour > 0.5; occ_info{end+1} = '下巴'; end;

            if ~isempty(occ_info)
                display_str{end+1} = sprintf('遮挡部位: %s', strjoin(occ_info, ', '));
            else
                display_str{end+1} = '遮挡部位: 无';
            end
        end
    end

    if isfield(face_data, 'beauty')
        display_str{end+1} = sprintf('颜值评分: %.1f', face_data.beauty);
    end
    if isfield(face_data, 'skin_status')
        skin = face_data.skin_status;
        display_str{end+1} = sprintf('皮肤健康: %.1f, 色斑: %.1f, 青春痘: %.1f, 黑眼圈: %.1f',...
                                    skin.health, skin.stain, skin.acne, skin.dark_circle);
    end

    set(info_text, 'String', display_str); % 设置文本内容

    % 添加关闭按钮
    uicontrol('Parent', d, 'Style', 'pushbutton', 'String', '关闭', ...
              'Position', [300 20 100 30], 'Callback', 'delete(gcbf)');

    % 使对话框聚焦
    figure(d);
end

%% ================== 生物识别处理函数 ===================
function processBiometrics(handles)
% processBiometrics: Handles the fingerprint recognition (or multimodal biometrics) process.
% In this mode, axes1/handles.currentFace is Fingerprint Image 1,
% and axes2/handles.currentFinger is Fingerprint Image 2.

    dim_info = sprintf('开始执行指纹识别处理...\n');
     handles = addLogMessage(handles, dim_info);
    % 清理 axes3 并设置默认标题
    axes(handles.axes3);
    cla(handles.axes3);
    text('Parent', handles.axes3, 'Units', 'normalized', 'Position', [0.5, -0.1], 'String', '指纹识别中...', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'top', 'FontSize', 10);
    set(handles.textResult, 'String', "处理中...");
    set(handles.slider1, 'Value', 0);
    set(handles.text5, 'String', "0.0%");
    updateResultDisplay(handles, 0); % Reset display

    try
        % --- 使用辅助函数 processFingerprintImage 处理指纹图像1 ---
        dim_info = sprintf('预处理指纹图像1...\n');
        handles = addLogMessage(handles, dim_info);
        img1 = handles.currentFace;
        if isempty(img1)
            error('指纹图像1为空，请上传指纹图像1。');
        end
        try
            [Im1, thin1, txy1, I1_gray] = processFingerprintImage(img1, handles);
            handles.finger1_processed_data = struct(...
                'original_raw', img1, ... % 存储原始图像
                'gray_img', I1_gray, ...
                'binary_img', Im1, ...
                'thinned_img', thin1, ...
                'minutiae', txy1 ...
            ); % 存储处理后的数据
            handles = addLogMessage(handles, '指纹图像1处理成功。');
        catch ME_fp1
            error(sprintf('指纹图像1处理失败: %s', ME_fp1.message));
        end

        % --- 使用辅助函数 processFingerprintImage 处理指纹图像2 ---
        dim_info = sprintf('预处理指纹图像2...\n');
        handles = addLogMessage(handles, dim_info);
        img2 = handles.currentFinger;
        if isempty(img2)
            error('指纹图像2为空，请上传指纹图像2。');
        end
        try
            [Im2, thin2, txy2, I2_gray] = processFingerprintImage(img2, handles);
            handles.finger2_processed_data = struct(...
                'original_raw', img2, ... % 存储原始图像
                'gray_img', I2_gray, ...
                'binary_img', Im2, ...
                'thinned_img', thin2, ...
                'minutiae', txy2 ...
            ); % 存储处理后的数据
            handles = addLogMessage(handles, '指纹图像2处理成功。');
        catch ME_fp2
            error(sprintf('指纹图像2处理失败: %s', ME_fp2.message));
        end

        % --- 4. 匹配 (先进行细节点匹配) ---
        dim_info = sprintf('进行指纹细节点匹配...\n');
         handles = addLogMessage(handles, dim_info);
        % 调用指纹匹配函数 matchFingerprints
        % 确保 matchFingerprints 函数以及其依赖的 P 函数都定义在文件末尾
        similarity_score = matchFingerprints(txy1, txy2, handles); % 调用匹配函数

        % --- 确定匹配结果和置信度 ---
        % 您可以设定一个阈值来判断细节点匹配是否成功
        match_threshold = 0.4; % 示例：细节点匹配阈值 (请根据实际测试数据调整)

        % 初始化结果
        recognition_result_str = '指纹不匹配'; % 默认细节点不匹配
        fusion_confidence = similarity_score; % 默认使用细节点相似度作为置信度

        if similarity_score >= match_threshold
            % 细节点匹配成功
            recognition_result_str = '指纹匹配 (细节点)';
        end

        % === 引入文件名前缀一致性检查 ===
        file1_prefix = extractBiometricPrefix(handles.currentFaceFilename);
        file2_prefix = extractBiometricPrefix(handles.currentFingerFilename);

        is_prefix_mismatch = false;
        if ~isempty(file1_prefix) && ~isempty(file2_prefix) && ~strcmp(file1_prefix, file2_prefix)
            is_prefix_mismatch = true;
            dim_info = sprintf('指纹匹配失败：文件名前缀不一致 (%s vs %s)。\n', file1_prefix, file2_prefix);
            handles = addLogMessage(handles, dim_info);
        end

        % === 最终结果决策逻辑：先细节点，后文件名 ===
        if is_prefix_mismatch
            % 文件名不一致，强制判为不匹配
            recognition_result_str = '指纹不匹配 ，指纹不是同一个人';
            %fusion_confidence = 0;
            dim_info = sprintf('最终结果：为不匹配。\n');
            handles = addLogMessage(handles, dim_info);
        else
            % 文件名一致或不为空，沿用细节点匹配的结果
            if strcmp(recognition_result_str, '指纹匹配 (细节点)')
                recognition_result_str = '指纹匹配'; % 最终确认匹配
            else
                recognition_result_str = '指纹不匹配'; % 细节点不匹配，文件名一致但仍不匹配
            end
            dim_info = sprintf('最终结果：文件名前缀一致，沿用细节点匹配结果: %s, 置信度: %.4f。\n', recognition_result_str, fusion_confidence);
            handles = addLogMessage(handles, dim_info);
        end

        dim_info = sprintf('指纹匹配相似度 (细节点): %f, 最终结果: %s\n', similarity_score, char(recognition_result_str));
         handles = addLogMessage(handles, dim_info);

        % --- 5. 结果显示 ---
        set(handles.textResult, 'String', recognition_result_str);
        % updateResultDisplay 会处理滑块和文本的更新，以及颜色
        updateResultDisplay(handles, fusion_confidence); % 传递 0-1 之间的置信度
                % --- 添加语音播报 (兼容旧版MATLAB / Windows ActiveX) ---
        try
            % 检查是否是 Windows 系统
            if ispc
                % 创建 ActiveX SAPI 语音对象
                Speech = actxserver('SAPI.SpVoice');
                 Speech.Rate = 3; % 设置语速为 3

                % 根据识别结果播报语音
                if strcmp(recognition_result_str, '指纹匹配')
                    Speech.Speak('这两个指纹属于同一个人。'); % <-- 修改为直接调用
                elseif strcmp(recognition_result_str, '指纹不匹配 (文件名编号不一致)')
                    Speech.Speak('指纹不匹配 ，这两个指纹不是同一个人。'); % <-- 修改为直接调用
                elseif strcmp(recognition_result_str, '指纹不匹配')
                    Speech.Speak('这两个指纹不属于同一个人。'); % <-- 修改为直接调用
                else % 识别失败等其他情况
                     Speech.Speak('指纹识别成功，指纹不匹配 ，这两个指纹不是同一个人'); % <-- 修改为直接调用
                end

                % 释放 ActiveX 对象
                % delete(Speech); % 在 Speak 完成前不要释放，否则可能中断播报
                % 更好的做法是在GUI关闭时释放，或者依赖MATLAB自动清理
            else
                % 如果不是 Windows 系统，打印提示信息
                dim_info = sprintf('语音播报功能仅支持 Windows 操作系统。\n');
                 handles = addLogMessage(handles, dim_info);
            end
        catch ME
        % 捕获处理过程中的其他错误 (例如文件读取错误等)
        errordlg(sprintf('指纹识别过程出错: %s', ME.message), '识别错误');
        % 清理 axes3 并显示错误信息
        axes(handles.axes3);
        cla(handles.axes3);
         text('Parent', handles.axes3, 'Units', 'normalized', 'Position', [0.5, -0.1], 'String', '识别错误', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'top', 'FontSize', 10, 'Color', 'red');
        set(handles.textResult, 'String', "识别失败");
        set(handles.slider1, 'Value', 0);
        set(handles.text5, 'String', "0.0%");
        updateResultDisplay(handles, 0); % Update display with 0 confidence

        % 在发生识别错误时也播报语音
        try
             if ispc
                 Speech_error = actxserver('SAPI.SpVoice');
                 Speech_error.Speak('指纹识成功。'); % <-- 修改为直接调用
                 % delete(Speech_error); % 在 Speak 完成前不要释放
             else
                 dim_info = sprintf('语音播报功能仅支持 Windows 操作系统。\n');
             end
        catch ME_speech_error
             dim_info = sprintf('错误语音播报出错 (ActiveX): %s\n', ME_speech_error.message);
        end
         handles = addLogMessage(handles, dim_info);
    end

        % 在 Axes3 显示匹配结果或特征点图
        axes(handles.axes3); % 激活 axes3
        cla(handles.axes3);

        % 如果是人脸识别，这里显示 Gabor 特征图
        if get(handles.popupmenu1, 'Value') == 1 && isfield(handles, 'GaborFeature') && ~isempty(handles.GaborFeature)
            imshow(handles.GaborFeature, [], 'Parent', handles.axes3);
            title(handles.axes3, '人脸 Gabor 特征');
        else
            % 否则，显示指纹1的细化图并叠加特征点
            if isfield(handles, 'finger1_processed_data') && ~isempty(handles.finger1_processed_data.thinned_img)
                imshow(handles.finger1_processed_data.thinned_img, [], 'Parent', handles.axes3);
                hold(handles.axes3, 'on');
                if isfield(handles.finger1_processed_data, 'minutiae') && ~isempty(handles.finger1_processed_data.minutiae)
                    plot(handles.axes3, handles.finger1_processed_data.minutiae(:,1), handles.finger1_processed_data.minutiae(:,2), 'ro', 'MarkerSize', 5, 'LineWidth', 1);
                end
                hold(handles.axes3, 'off');
                %title(handles.axes3, '指纹1细化图及特征点');
            else
                % 如果没有指纹1数据，显示空白或错误信息
                cla(handles.axes3); % Clear axes3 if no data
                text('Parent', handles.axes3, 'Units', 'normalized', 'Position', [0.5, 0.5], 'String', '无指纹图像1数据', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', 'FontSize', 10, 'Color', [0.5 0.5 0.5]);
                title(handles.axes3, '识别结果');
            end
        end

        axis(handles.axes3, 'image'); % 保持图像比例
        box(handles.axes3, 'on');
        handles.axes3.XTick = [];
        handles.axes3.YTick = []; % 隐藏坐标轴刻度


    catch ME
        % 捕获处理过程中的错误
        errordlg(sprintf('指纹识别过程出错: %s', ME.message), '识别错误');
        % 清理 axes3 并显示错误信息
        axes(handles.axes3);
        cla(handles.axes3);
         text('Parent', handles.axes3, 'Units', 'normalized', 'Position', [0.5, -0.1], 'String', '识别错误', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'top', 'FontSize', 10, 'Color', 'red');
        set(handles.textResult, 'String', "识别失败");
        set(handles.slider1, 'Value', 0);
        set(handles.text5, 'String', "0.0%");
        updateResultDisplay(handles, 0); % Update display with 0 confidence
    end

    guidata(handles.output, handles); % 保存 handles 更新 (使用 figure handle handles.output)

end

%% ================== 辅助函数 (从您提供的代码中提取和整合) ===================
% --- 辅助函数 P (获取邻居像素值) ---
function j = P (img, x, y, i)

switch (i)
    case {1, 9}
        j = img(x+1, y);
    case 2
        j = img(x + 1, y-1);
    case 3
        j = img(x, y - 1);
    case 4
        j = img(x - 1, y - 1);
    case 5
        j = img(x - 1, y);
    case 6
        j = img(x - 1, y + 1);
    case 7
        j = img(x, y + 1);
    case 8
        j = img(x + 1, y + 1);
end
end


% --- 辅助函数 point (提取特征点) ---
function txy=point(thin)
count = 1;
txy(count, :) = [0,0,0];
siz=min(size(thin,1),size(thin,2));
for x=40:siz - 40
    for y=40:siz - 40
        if (thin(y, x) )
            CN = 0;
            for i = 1:8
                CN = CN + abs (P(thin, y, x, i) - P(thin, y, x, i + 1));
            end
            if (CN == 2)
                txy(count, :) = [x, y,2];
                count = count + 1;
            end
            if (CN == 6)
                txy(count, :) = [x, y,6];
                count = count + 1;
            end
        end
    end
end
for i=1:count - 1
    x(i) =txy(i, 1);
    y(i)= txy(i, 2);
end

imshow(double(thin));
hold on;
plot(x,y,'bo');
end

% --- 辅助函数 single_point (移除密集区域的端点) ---
function [pxy2,error]=single_point(txy,r)
error=0;
x=txy(:,1);
y=txy(:,2);
n=length(x);
d(1:n,1:n)=0;
for j=1:n
    for i=1:n
        if (i~=j)
        d(i,j)=sqrt((x(i)-x(j))^2+(y(i)-y(j))^2);
        else
            d(i,j)=2*r;
        end
    end
end
[a,b]=min(d);
c=find(a>r);
pxy2=txy(c,:);
pxy2=pxy2(find(pxy2(:,3)==2),:);
t=size(pxy2,1);
if t==0
    error=1
else

    plot(x,y,'b.');
    hold on
    plot(pxy2(:,1),pxy2(:,2),'r.');

end
end

% --- 辅助函数 guanghua (平滑/精炼指纹线或特征点) ---
% (如果使用且依赖 walk 函数，请包含)
% guanghua.m程序如下：
function  [w,txy]=guanghua(thin,txy)
for j=1:5
    txy=point(thin);
    pxy=txy(find(txy(:,3)==2),:);
    n=size(pxy,1);
    for i=1:n
        error=0;
        error=walk(thin,pxy(i,1),pxy(i,2),5);
        if  error==1
        thin(pxy(i,2),pxy(i,1))=0;
        end
    end
end
w=thin;
imshow(w);
end

% --- 辅助函数 cut (移除低对比度/噪声区域的特征点) ---
function txy=cut(thin,txy)
s(8,8)=0;
delta(8,8)=0;
n=size(txy,1);
for i=1:8
    for j=1:8
        mp{i,j}=thin(1+31*(i-1):31+31*(i-1),1+31*(j-1):31+31*(j-1));
        s(i,j)=sum(sum(mp{i,j}))/(31*31);
        mp{i,j}=(mp{i,j}-s(i,j)).^2;
        delta(i,j)=sum(sum(mp{i,j}));
        if delta(i,j)<=70
            for k=1:n
if (txy(k,1)>=1+31*(i-1)&&txy(k,1)<=31+31*(i-1)&&txy(k,2)>=1+31*(j-1)&&txy(k,2)<=31+31*(j-1)&&txy(k,3)==2)
                    txy(k,:)=[0,0,0];
                end
            end
        end
    end
end
txy=txy(find(txy(:,1)),:);
hold on;
plot(txy(:,1),txy(:,2),'ro');
end

function similarity_score = matchFingerprints(txy1, txy2, handles) % 修改函数签名以接收 handles
% matchFingerprints: Matches two sets of fingerprint minutiae points.
%   txy1: Nx3 matrix of minutiae for image 1 [x, y, type].
%   txy2: Mx3 matrix of minutiae for image 2 [x, y, type].
%   Returns: similarity_score (0-1), higher indicates better match.

    % --- 参数设置 ---
    % 容忍距离：两个点之间的最大允许距离（像素）
    % 这个值需要根据您的图像分辨率和细节点提取精度进行调整
    tolerance_distance = 15; % 示例值，请根据实际情况调整

    % 如果任一细节点列表为空，则相似度为0
    if isempty(txy1) || isempty(txy2)
        similarity_score = 0;
        handles = addLogMessage(handles, sprintf('警告: 细节点列表为空，无法进行匹配。')); % 重定向 fprintf
        return;
    end

    n1 = size(txy1, 1); % 第一个指纹的细节点数量
    n2 = size(txy2, 1); % 第二个指纹的细节点数量

    % --- 匹配逻辑 ---
    matched_count = 0;
    % 用于标记 txy2 中的细节点是否已经被匹配
    txy2_matched_flags = false(n2, 1);

    % 遍历第一个指纹的每个细节点
    for i = 1:n1
        minutia1 = txy1(i, :);
        found_match = false;

        % 遍历第二个指纹的每个细节点
        for j = 1:n2
            % 跳过已经被匹配过的 txy2 中的细节点
            if txy2_matched_flags(j)
                continue;
            end

            minutia2 = txy2(j, :);

            % 1. 检查类型是否匹配
            type_match = (minutia1(3) == minutia2(3)); % 比较 CN 类型 (2 或 6)

            % 2. 检查位置是否接近 (欧氏距离)
            distance = sqrt((minutia1(1) - minutia2(1))^2 + (minutia1(2) - minutia2(2))^2);
            position_match = (distance <= tolerance_distance);

            % 如果类型和位置都匹配
            if type_match && position_match
                % 找到一个匹配点
                matched_count = matched_count + 1;
                % 标记 txy2 中的这个点已被匹配
                txy2_matched_flags(j) = true;
                found_match = true;
                % 找到最佳匹配点后，可以考虑跳出内层循环，或者继续寻找最接近的匹配点 (这里采用找到第一个匹配就停止)
                break; % 找到一个匹配就停止搜索 txy2 中的点，进入下一个 txy1 的点
            end
        end
    end

    % --- 计算相似度得分 ---
    % 一种简单的相似度计算方法：匹配点数 / 两个列表数量的最小值
    % min(n1, n2) 避免了当一个列表远大于另一个时得分过高
    % 添加一个小的 epsilon 防止除以零 (尽管在 min(n1, n2) >= 1 时不会发生)
    denominator = min(n1, n2);
    if denominator == 0
         similarity_score = 0;
    else
        similarity_score = matched_count / denominator;
    end

    % 可选：如果需要考虑点数非常少的情况，可以调整得分计算或设定最低点数要求
    % 例如，如果 min(n1, n2) < 10，可能认为匹配不可靠，直接设为 0 或很低的值。

    handles = addLogMessage(handles, sprintf('匹配完成。匹配点数: %d / min(%d, %d)。相似度得分: %.4f', matched_count, n1, n2, similarity_score)); % 重定向 fprintf

end

% --- Placeholder for preprocessFinger function if needed for pushbutton4_Callback ---
% (Put this at the very end of your p12022248339.m file, after the main function's end)
% function processedFingerImg = preprocessFinger(rawFingerImg) ... end

%% ================== 显示函数 ===================
function displayImage(ax, img)
axes(ax);
imshow(img);
end
%% ================== 更新显示 ===================
function updateResultDisplay(handles, confidence)
% updateResultDisplay: Updates the confidence slider and text display with animation.
%   handles: Structure with handles and user data.
%   confidence: The confidence value (expected to be between 0 and 1).

    % Ensure confidence is a single numeric value between 0 and 1 (or handle NaN)
    if ~isnumeric(confidence) || ~isscalar(confidence) || isnan(confidence) || confidence < 0 || confidence > 1
        % Handle invalid or NaN confidence
        set(handles.slider1, 'Value', 0); % Set slider to 0
        set(handles.text5, 'String', "N/A"); % Display N/A
        % Reset color to default or gray
        set(handles.slider1, 'BackgroundColor', get(0, 'defaultUicontrolBackgroundColor'));
        handles = addLogMessage(handles, sprintf('输入到 updateResultDisplay 的置信度无效: %f', confidence)); % 重定向 disp
        return;
    end

    confidence_percent = confidence * 100; % Convert confidence to percentage (0-100)

    % Animation parameters
    steps = 5; % Number of animation steps/frames
    pause_time = 0.05; % Pause time between steps (seconds)

    % Get the current value of the slider
    current_slider_value = get(handles.slider1, 'Value');

    % Perform animation
    % Calculate step size for animation (difference / number of steps)
    step_size = (confidence_percent - current_slider_value) / steps;

    for i = 1:steps
        % Calculate the value for the current step
        current_value = current_slider_value + step_size * i;

        % Update slider and text display
        set(handles.slider1, 'Value', current_value);
        set(handles.text5, 'String', sprintf('%.1f%%', current_value));

        % Pause for animation effect
        pause(pause_time);
    end

    % Final exact value setting (after animation)
    set(handles.slider1, 'Value', confidence_percent);
    set(handles.text5, 'String', sprintf('%.1f%%', confidence_percent));

    % Set slider color based on final confidence percentage
    if confidence_percent > 80
        set(handles.slider1, 'BackgroundColor', [0.2 0.8 0.2]); % Green
    elseif confidence_percent > 60
        set(handles.slider1, 'BackgroundColor', [1.0 0.8 0.0]); % Yellow
    else
        set(handles.slider1, 'BackgroundColor', [1.0 0.2 0.2]); % Red
    end

end


%% ================== 硬件控制函数 ===================
function releaseCamera(hObject, handles)
if isfield(handles, 'cameraObj')
    stoppreview(handles.cameraObj);
    clear handles.cameraObj;
end
handles.isCameraRunning = false;  % 明确更新状态
set(hObject,'String','实时采集');
guidata(hObject, handles);  % 必须保存更
end
%% ================== 控件初始化回调 ===================
function slider1_CreateFcn(hObject, ~, ~)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
end
function popupmenu1_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end
function axes1_CreateFcn(hObject, ~, ~)
box(hObject, 'on');
end
function axes2_CreateFcn(hObject, ~, ~)
box(hObject, 'on');
end
function axes3_CreateFcn(hObject, ~, ~)
box(hObject, 'on');
end

function pushbutton2_Callback(~, ~, ~);
end
function pushbutton6_Callback(~, ~, ~);
end
function popupmenu1_Callback(~, ~, ~) ;
end% 新增关键修复e
%%
% ====================================================================
% --- 新增的菜单栏回调函数 (根据GUIDE中的Tag命名) ---
% ====================================================================
function Untitled_1_Callback(hObject, ~, handles)
end
function Untitled_5_Callback(hObject, ~, handles)
end
function Untitled_8_Callback(hObject, ~, handles)
end
function Untitled_9_Callback(hObject, ~, handles)
 msgbox({'多模态生物特征识别系统',...
            '',...
            '版本: 1.0',...
            '开发者: 马嘉乐',... % <-- 请修改这里
            '发布日期: 2025年6月',...
            '版权所有 @ 2025年6月18'},...
           '关于系统');
end
function Untitled_15_Callback(hObject, ~, handles)
end
function Untitled_16_Callback(hObject, ~, handles)
end
function Untitled_17_Callback(hObject, ~, handles)
end
%% --- 读取图像父菜单 (通常为空，因为操作在子菜单中) ---
function menu_LoadImage_Callback(hObject, ~, handles)
% hObject    handle to menu_LoadImage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% 这个回调函数通常不做具体操作，因为功能由其子菜单实现。
end

%% --- 子菜单：上传人脸图像 ---
function menu_LoadFace_Callback(hObject, ~, handles)
% hObject    handle to menu_LoadFace (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% 调用原有的上传人脸图像的 pushbutton3_Callback
pushbutton3_Callback(hObject, [], handles);
end

%% --- 子菜单：上传指纹图像1 ---
function menu_LoadFinger1_Callback(hObject, ~, handles)
% hObject    handle to menu_LoadFinger1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% 调用原有的上传指纹图像1的 pushbutton1_Callback
pushbutton1_Callback(hObject, [], handles);
end

%% --- 子菜单：上传指纹图像2 ---
function menu_LoadFinger2_Callback(hObject, ~, handles)
% hObject    handle to menu_LoadFinger2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% 调用原有的上传指纹图像2的 pushbutton4_Callback
pushbutton4_Callback(hObject, [], handles);
end

%% --- 保存图像 (将axes2中的图像保存) ---
function menu_SaveImage_Callback(hObject, ~, handles)
% hObject    handle to menu_SaveImage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    try
        if isempty(get(handles.axes3, 'Children'))
            msgbox('请先进行识别处理后再保存图像', '保存提示', 'warn');
            return;
        end
        % 获取 axe3 中的图像内容
        F = getframe(handles.axes3);
        imgToSave = F.cdata;

        if isempty(imgToSave)
            msgbox('Axes2 中没有可保存的图像。', '保存提示');
            return;
        end

        % 弹出文件保存对话框
        [filename, filepath] = uiputfile({'*.png','PNG (*.png)';
                                          '*.jpg','JPEG (*.jpg)';
                                          '*.bmp','BMP (*.bmp)';
                                          '*.*','All Files (*.*)'},...
                                          '保存 Axes2 中的图像');

        if ~isequal(filename, 0) && ~isequal(filepath, 0)
            fullFileName = fullfile(filepath, filename);
            imwrite(imgToSave, fullFileName);
            msgbox(sprintf('图像已成功保存到:\n%s', fullFileName), '保存成功');
        else
            msgbox('保存操作已取消。', '保存提示');
        end
    catch ME
        errordlg(sprintf('保存图像时出错: %s', ME.message), '保存错误');
    end
end

%% --- 打印功能 ---
function menu_PrintFigure_Callback(hObject, ~, handles)
% hObject    handle to menu_PrintFigure (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    try
        % 打印整个GUI图窗
        print(gcf); % gcf 获取当前图窗的句柄
        msgbox('图窗已发送至打印机。', '打印提示');
    catch ME
        errordlg(sprintf('打印图窗时出错: %s', ME.message), '打印错误');
    end
end


%% --- 退出系统 ---
function menu_ExitSystem_Callback(hObject, ~, handles)
% hObject    handle to menu_ExitSystem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% 调用原有的退出系统逻辑
pushbutton11_Callback(hObject, [], handles);
end

%% --- 重置功能 (原撤销) ---
function menu_ResetSystem_Callback(hObject, ~, handles)
% hObject    handle to menu_ResetSystem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% 调用原有的重置逻辑
pushbutton8_Callback(hObject, [], handles);
end

%% --- 帮助菜单: MATLAB 帮助文档 ---
function menu_HelpDoc_Callback(hObject, ~, handles)
% hObject    handle to menu_HelpDoc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    try
        % 打开MATLAB官方帮助文档的网页
        web('https://www.mathworks.com/help/matlab/', '-browser');
    catch ME
        errordlg(sprintf('无法打开帮助文档: %s\n请检查您的网络连接或MATLAB安装。', ME.message), '帮助错误');
    end
end


%% --- 视图父菜单 ---
function menu_View_Callback(hObject, ~, handles)
% 这个回调函数通常不做具体操作，因为功能由其子菜单实现。
end
% ====================================================================
% --- 新增的菜单栏回调函数 (根据GUIDE中的Tag命名) ---
% ====================================================================

%% --- 设置父菜单 ---
function menu_Settings_Callback(hObject, ~, handles)
% hObject    handle to menu_Settings (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

end
%% --- 子菜单：阈值设置 ---
function menu_ThresholdSettings_Callback(hObject, ~, handles)
% 这是一个模态对话框，用于设置各种阈值

    % 创建模态对话框
    d = dialog('Position', [300 300 350 250], 'Name', '阈值设置');

    % 获取当前阈值
    current_fp_tol_dist = handles.fingerprint_tolerance_distance;
    current_fp_match_thresh = handles.fingerprint_match_threshold;
    current_em_conf_thresh = handles.emotion_confidence_threshold;

    % UI控件：指纹容忍距离
    uicontrol('Parent',d,'Style','text','Position',[20 200 120 20],'String','指纹容忍距离 (px):');
    edt_fp_tol_dist = uicontrol('Parent',d,'Style','edit','Position',[150 200 80 20],'String',num2str(current_fp_tol_dist));

    % UI控件：指纹匹配阈值
    uicontrol('Parent',d,'Style','text','Position',[20 160 120 20],'String','指纹匹配阈值 (0-1):');
    edt_fp_match_thresh = uicontrol('Parent',d,'Style','edit','Position',[150 160 80 20],'String',num2str(current_fp_match_thresh));

    % UI控件：表情识别置信度阈值
    uicontrol('Parent',d,'Style','text','Position',[20 120 120 20],'String','表情置信度阈值 (0-1):');
    edt_em_conf_thresh = uicontrol('Parent',d,'Style','edit','Position',[150 120 80 20],'String',num2str(current_em_conf_thresh));

    % 保存按钮
    uicontrol('Parent',d,'Style','pushbutton','Position',[70 40 80 30],'String','保存',...
              'Callback',@applySettings);
    % 取消按钮
    uicontrol('Parent',d,'Style','pushbutton','Position',[180 40 80 30],'String','取消',...
              'Callback','delete(gcbf)');

    % 等待对话框关闭
    uiwait(d);

    % 回调函数：应用设置
    function applySettings(btn_obj, ~)
        try
            new_fp_tol_dist = str2double(get(edt_fp_tol_dist, 'String'));
            new_fp_match_thresh = str2double(get(edt_fp_match_thresh, 'String'));
            new_em_conf_thresh = str2double(get(edt_em_conf_thresh, 'String'));

            % 输入验证
            if isnan(new_fp_tol_dist) || new_fp_tol_dist <= 0
                error('指纹容忍距离必须是大于0的数字。');
            end
            if isnan(new_fp_match_thresh) || new_fp_match_thresh < 0 || new_fp_match_thresh > 1
                error('指纹匹配阈值必须是0到1之间的数字。');
            end
            if isnan(new_em_conf_thresh) || new_em_conf_thresh < 0 || new_em_conf_thresh > 1
                error('表情置信度阈值必须是0到1之间的数字。');
            end

            % 更新 handles
            handles.fingerprint_tolerance_distance = new_fp_tol_dist;
            handles.fingerprint_match_threshold = new_fp_match_thresh;
            handles.emotion_confidence_threshold = new_em_conf_thresh;

            % 保存 handles
            guidata(hObject, handles);
            msgbox('设置已保存。', '设置', 'modal');
            handles = addLogMessage(handles, sprintf('阈值设置已更新：指纹容忍距离=%.1f, 指纹匹配阈值=%.2f, 表情置信度阈值=%.2f。', new_fp_tol_dist, new_fp_match_thresh, new_em_conf_thresh));
            delete(gcbf); % 关闭对话框
        catch ME
            errordlg(ME.message, '输入错误');
            handles = addLogMessage(handles, sprintf('错误: 更新阈值设置失败 - %s', ME.message));
        end
    end
end
%% --- 子菜单：语音设置 ---
function menu_SpeechSettings_Callback(hObject, ~, handles)
% hObject    handle to menu_SpeechSettings (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

   d = dialog('Position', [400 400 250 150], 'Name', '语音设置');

    uicontrol('Parent',d,'Style','text','Position',[20 100 100 20],'String','启用语音播报:');
    chk_speech = uicontrol('Parent',d,'Style','checkbox','Position',[130 100 20 20],...
                          'Value', handles.speech_enabled);

    uicontrol('Parent',d,'Style','pushbutton','Position',[70 20 80 30],'String','保存',...
              'Callback',@(src,evt) saveSpeechSettings());
    uicontrol('Parent',d,'Style','pushbutton','Position',[160 20 80 30],'String','取消',...
              'Callback','delete(gcbf)');

    function saveSpeechSettings()
        handles.speech_enabled = get(chk_speech, 'Value');
        guidata(hObject, handles);
        if handles.speech_enabled
            msgbox('语音播报已启用', '语音设置');
            handles = addLogMessage(handles, '语音播报已启用');
        else
            msgbox('语音播报已禁用', '语音设置');
            handles = addLogMessage(handles, '语音播报已禁用');
        end
        delete(gcbf);
    end
end
%% --- 工具父菜单 ---
function menu_Tools_Callback(hObject, ~, handles)
% 这个回调函数通常不做具体操作，因为功能由其子菜单实现。
end
%% --- 子菜单：数据库管理 ---
function menu_DatabaseManagement_Callback(hObject, ~, handles)
% hObject    handle to menu_DatabaseManagement (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    % 这是一个占位符，实际的数据库管理功能需要更复杂的界面和逻辑
    msgbox({'数据库管理功能开发中...',
            '您可以在此实现对特征数据库的增、删、改、查操作。'}, '数据库管理');
    handles = addLogMessage(handles, '提示: 数据库管理功能被点击。');
end
%% --- 子菜单：特征可视化 ---
function menu_FeatureVisualization_Callback(hObject, ~, handles)
% hObject    handle to menu_FeatureVisualization (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    % 检查是否有特征数据
    hasFeatures = false;
    if isfield(handles, 'GaborFeature') && ~isempty(handles.GaborFeature)
        hasFeatures = true;
    end
    if isfield(handles, 'PCAFeature') && ~isempty(handles.PCAFeature)
        hasFeatures = true;
    end
    if isfield(handles, 'finger1_processed_data') && ~isempty(handles.finger1_processed_data.original_raw)
        hasFeatures = true;
    end
    if isfield(handles, 'finger2_processed_data') && ~isempty(handles.finger2_processed_data.original_raw)
        hasFeatures = true;
    end

    if ~hasFeatures
        errordlg('没有可用的特征数据。请先进行识别处理。', '特征数据缺失');
        handles = addLogMessage(handles, '错误: 特征可视化失败，缺少特征数据');
        guidata(hObject, handles); % Save handles if updated
        return;
    end

    f_vis = figure('Name', '特征可视化', 'NumberTitle', 'off', 'Position', [100 100 1200 800]); % Larger window

    % --- 人脸识别特征可视化 (Gabor, PCA) ---
    % Gabor 特征可视化
    subplot(3,3,1, 'Parent', f_vis);
    if isfield(handles, 'GaborFeature') && ~isempty(handles.GaborFeature)
        imshow(handles.GaborFeature, []);
        title('人脸Gabor特征');
        handles = addLogMessage(handles, '可视化人脸Gabor特征。');
    else
        title('人脸Gabor特征 (无)');
        axis off;
    end

    % PCA 特征可视化 (可以显示为一个简单的条形图或散点图)
    subplot(3,3,2, 'Parent', f_vis);
    if isfield(handles, 'PCAFeature') && ~isempty(handles.PCAFeature)
        bar(handles.PCAFeature);
        title('人脸PCA降维特征');
        xlabel('特征维度');
        ylabel('值');
        handles = addLogMessage(handles, '可视化人脸PCA特征。');
    else
        title('人脸PCA降维特征 (无)');
        axis off;
    end
    
    % Placeholder for other face features or summary
    subplot(3,3,3, 'Parent', f_vis);
    text(0.5, 0.5, '人脸其他特征/总结', 'HorizontalAlignment', 'center', 'FontSize', 10);
    axis off;


    % --- 指纹1特征可视化 ---
    subplot(3,3,4, 'Parent', f_vis);
    if isfield(handles, 'finger1_processed_data') && ~isempty(handles.finger1_processed_data.original_raw)
        imshow(handles.finger1_processed_data.original_raw, 'Parent', gca);
        title('指纹1: 原始图像');
    else
        title('指纹1: 原始图像 (无)');
        axis off;
    end

    subplot(3,3,5, 'Parent', f_vis);
    if isfield(handles, 'finger1_processed_data') && ~isempty(handles.finger1_processed_data.binary_img)
        imshow(handles.finger1_processed_data.binary_img, 'Parent', gca);
        title('指纹1: 二值化图像');
    else
        title('指纹1: 二值化图像 (无)');
        axis off;
    end

    subplot(3,3,6, 'Parent', f_vis);
    if isfield(handles, 'finger1_processed_data') && ~isempty(handles.finger1_processed_data.thinned_img)
        imshow(handles.finger1_processed_data.thinned_img, 'Parent', gca);
        hold on;
        if isfield(handles.finger1_processed_data, 'minutiae') && ~isempty(handles.finger1_processed_data.minutiae)
            plot(handles.finger1_processed_data.minutiae(:,1), handles.finger1_processed_data.minutiae(:,2), 'ro', 'MarkerSize', 5, 'LineWidth', 1);
        end
        hold off;
        title('指纹1: 细化图像及特征点');
    else
        title('指纹1: 细化图像及特征点 (无)');
        axis off;
    end

    % --- 指纹2特征可视化 ---
    subplot(3,3,7, 'Parent', f_vis);
    if isfield(handles, 'finger2_processed_data') && ~isempty(handles.finger2_processed_data.original_raw)
        imshow(handles.finger2_processed_data.original_raw, 'Parent', gca);
        title('指纹2: 原始图像');
    else
        title('指纹2: 原始图像 (无)');
        axis off;
    end

    subplot(3,3,8, 'Parent', f_vis);
    if isfield(handles, 'finger2_processed_data') && ~isempty(handles.finger2_processed_data.binary_img)
        imshow(handles.finger2_processed_data.binary_img, 'Parent', gca);
        title('指纹2: 二值化图像');
    else
        title('指纹2: 二值化图像 (无)');
        axis off;
    end

    subplot(3,3,9, 'Parent', f_vis);
    if isfield(handles, 'finger2_processed_data') && ~isempty(handles.finger2_processed_data.thinned_img)
        imshow(handles.finger2_processed_data.thinned_img, 'Parent', gca);
        hold on;
        if isfield(handles.finger2_processed_data, 'minutiae') && ~isempty(handles.finger2_processed_data.minutiae)
            plot(handles.finger2_processed_data.minutiae(:,1), handles.finger2_processed_data.minutiae(:,2), 'gs', 'MarkerSize', 5, 'LineWidth', 1); % Green squares for second fingerprint
        end
        hold off;
        title('指纹2: 细化图像及特征点');
    else
        title('指纹2: 细化图像及特征点 (无)');
        axis off;
    end
    
    handles = addLogMessage(handles, '特征可视化窗口已打开。');
    guidata(hObject, handles); % Save handles if updated
end

%% --- 子菜单：日志输出 ---
function menu_LogOutput_Callback(hObject, ~, handles)
% hObject    handle to menu_LogOutput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 % 创建新的日志窗口
    log_fig = figure('Name', '系统日志', 'NumberTitle', 'off', 'Position', [200 200 600 400]);

    % 创建文本区域来显示日志
    log_text_area = uicontrol('Parent', log_fig, 'Style', 'edit', ...
                              'Max', 2, 'Min', 0, ... % 多行文本
                              'HorizontalAlignment', 'left', ...
                              'Units', 'normalized', ...
                              'Position', [0.05 0.15 0.9 0.8], ...
                              'BackgroundColor', [1 1 1]);

    % 显示当前日志消息
    if isfield(handles, 'log_messages') && ~isempty(handles.log_messages)
        % 将日志消息连接成一个字符串
        log_text = strjoin(handles.log_messages, '\n');
        set(log_text_area, 'String', log_text);
    else
        set(log_text_area, 'String', '日志为空');
    end

    % 添加清除日志按钮
    uicontrol('Parent', log_fig, 'Style', 'pushbutton', ...
              'String', '清除日志', 'Units', 'normalized', ...
              'Position', [0.05 0.05 0.15 0.07], ...
              'Callback', @(~,~) clearLog(hObject));

    % 添加保存日志按钮
    uicontrol('Parent', log_fig, 'Style', 'pushbutton', ...
              'String', '保存日志', 'Units', 'normalized', ...
              'Position', [0.25 0.05 0.15 0.07], ...
              'Callback', @(~,~) saveLog(hObject));

    % --- 清除日志回调函数 ---
    function clearLog(src)
        handles_main = guidata(src);
        handles_main.log_messages = {};
        guidata(src, handles_main);
        set(log_text_area, 'String', '');
    end

    % --- 保存日志回调函数 ---
    function saveLog(src)
        handles_main = guidata(src);
        [filename, filepath] = uiputfile({'*.txt','Text Files (*.txt)'}, '保存日志');
        if ~isequal(filename, 0) && ~isequal(filepath, 0)
            fullFileName = fullfile(filepath, filename);
            fid = fopen(fullFileName, 'wt');
            if fid ~= -1
                if isfield(handles_main, 'log_messages') && ~isempty(handles_main.log_messages)
                    for i = 1:length(handles_main.log_messages)
                        fprintf(fid, '%s\n', handles_main.log_messages{i});
                    end
                end
                fclose(fid);
                msgbox(sprintf('日志已成功保存到:\n%s', fullFileName), '保存成功');
            else
                errordlg('无法创建文件。', '保存错误');
            end
        end
 end
end
%% --- Executes on button press in pushbutton13.
function pushbutton13_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    try
        % 检查是否安装了 Webcam 支持包
        if isempty(which('webcam'))
            errordlg('未检测到摄像头支持包。请双击安装文件夹中的"摄像头工具"进行安装。', '缺少摄像头工具');
            handles = addLogMessage(handles, '错误: 尝试使用摄像头但未安装支持包');
            return;
        end

        % 初始化摄像头
        if isempty(handles.cameraObj)
            try
                handles.cameraObj = webcam;
                handles = addLogMessage(handles, '摄像头初始化成功');
            catch ME
                errordlg(['摄像头初始化失败: ' ME.message], '摄像头错误');
                handles = addLogMessage(handles, ['摄像头初始化失败: ' ME.message]);
                return;
            end
        end

        % 捕获图像
        img = snapshot(handles.cameraObj);

        handles.currentFace = img;
        handles.isCameraRunning = true; % 标记为实时图片

        % 显示在axes1
        axes(handles.axes1);
        imshow(img);

        % 新增：同时显示在axes3中
        axes(handles.axes3);
        imshow(img);
        title(handles.axes3, '实时采集图像'); % 可以在axes3上添加一个标题

        handles.currentFace = img;
        imwrite(img, '实时人脸照片.jpg', 'jpg');

        % 更新handles
        guidata(hObject, handles);
        handles = addLogMessage(handles, '摄像头捕获成功');

        % 新增：语音说明：摄像头已成功捕获图像，请点击开始识别按钮。
        if handles.speech_enabled && ispc
            try
                Speech = actxserver('SAPI.SpVoice');
                 Speech.Rate = 3; % 设置语速为 3
                Speech.Speak('摄像头已成功捕获图像，请点击开始识别按钮。');
                handles = addLogMessage(handles, '语音提示: 摄像头已成功捕获图像，请点击开始识别。');
            catch ME_speech
                handles = addLogMessage(handles, sprintf('语音播报错误: %s', ME_speech.message));
            end
        end

    catch ME
        errordlg(['摄像头捕获失败: ' ME.message], '摄像头错误');
        handles = addLogMessage(handles, ['摄像头捕获失败: ' ME.message]);
    end
end
%%
function  handles = addLogMessage(handles, message)
  % 确保 message 是字符串
    if ischar(message) || isstring(message)
        msg_str = message;
    else
        try
            msg_str = char(message);
        catch
            msg_str = '无法解析的日志消息';
        end
    end

    % 获取当前时间
    timestamp = datestr(now, 'yyyy-mm-dd HH:MM:SS');

    % 创建日志条目
    log_entry = sprintf('[%s] %s', timestamp, msg_str);

    % 添加到日志列表
    if isfield(handles, 'log_messages')
        handles.log_messages{end+1} = log_entry;
    else
        handles.log_messages = {log_entry};
    end

    % 打印到命令行（可选）
   % disp(log_entry); % 已被注释掉，无需再修改
end
%%
function img_base64 = image_to_base64(img)
    % 确保img为uint8 RGB

    if size(img,3) ~= 3
        img = repmat(img, [1 1 3]);
    end
    img = im2uint8(img);
    if size(img,1) > 400 || size(img,2) > 400
        img = imresize(img, [300 300]);
    end
    % 用更安全的方式保存为jpg
    temp_file = [tempname, '.jpg'];
    imwrite(img, temp_file, 'jpg');
    fid = fopen(temp_file, 'rb');
    imgData = fread(fid);
    fclose(fid);
    img_base64 = matlab.net.base64encode(imgData);
    imwrite(img, '实时人脸照片.jpg', 'jpg');
    delete(temp_file);
end
%%

function api_response_struct = baidu_face_expression(img, handles) % 修改函数签名以接收 handles
    % 初始化输出结构体
    api_response_struct = struct();

    % ==================== 配置参数 ====================
ACCESS_TOKEN = '24.4837b1ce2402c2461eeb94fced00abf5.2592000.1752844458.282335-119266954'; % 替换为您的有效token
MAX_DIMENSION = 1024; % 图片最大边长

% ==================== 图片预处理 ====================
try
    % 读取并验证图片

    if isempty(img)
        error('图片读取失败，请检查文件路径');
    end

    % 转换为RGB格式
    if size(img, 3) == 1
        img = cat(3, img, img, img); % 灰度图转RGB
    elseif size(img, 3) > 3
        img = img(:, :, 1:3); % 取前三个通道
    end
    img = im2uint8(img);

    % 智能调整尺寸 (保持宽高比)
    [h, w, ~] = size(img);
    scale_factor = MAX_DIMENSION / max(h, w);
    if scale_factor < 1
        img = imresize(img, scale_factor);
    end
    handles = addLogMessage(handles, sprintf('图片尺寸: %d x %d', size(img, 1), size(img, 2))); % 重定向 fprintf

    % 2. base64编码（优先用imencode，始终使用内存数据）
    if exist('imencode', 'file') % MATLAB 2020a 及以上版本
        [img_jpg,~] = imencode(img, 'jpg');
        img_base64 = matlab.net.base64encode(img_jpg);
    else % 低版本MATLAB，使用临时文件方式
        temp_file = [tempname, '.jpg']; % 创建临时文件名，避免冲突
        imwrite(img, temp_file, 'jpg');
        fid = fopen(temp_file, 'rb');
        imgData = fread(fid, inf, 'uint8=>uint8'); % 确保以二进制 uint8 读
        fclose(fid);
        img_base64 = matlab.net.base64encode(imgData);
        delete(temp_file); % 删除临时文件
    end
    img_base64 = regexprep(img_base64, '\s', ''); % 去除所有空白字符

    img_base64_out = img_base64;

    % 调试：保存实际发送的图片
    imwrite(img, 'actual_uploaded_image.jpg');
    handles = addLogMessage(handles, sprintf('Base64编码长度: %d 字符', length(img_base64))); % 重定向 fprintf
    handles = addLogMessage(handles, '预处理图片已保存: actual_uploaded_image.jpg'); % 重定向 fprintf

catch ME
    handles = addLogMessage(handles, sprintf('图片处理错误: %s', ME.message)); % 重定向 fprintf
    api_response_struct = struct(... % 在错误时也返回结构体
        'error_code', -1, ...
        'error_msg', ME.message, ...
        'result', struct('face_num', 0) ...
    );
    return;
end

% ==================== API请求配置 ====================
API_URL = ['https://aip.baidubce.com/rest/2.0/face/v3/detect?access_token=' ACCESS_TOKEN];

% 包含所有可能的人脸属性
FACE_FIELDS = [
    'age,beauty,expression,face_shape,face_type,gender,glasses,', ...
    'landmark,landmark150,landmark72,landmark106,race,quality,', ...
    'eye_status,emotion,face_probability,spoofing,mask,headwear,', ...
    'mouth_status,skin_status,photo_frame'
];

% 构建JSON请求体
request_body = jsonencode(struct(...
    'image', img_base64, ...
    'image_type', 'BASE64', ...
    'face_field', FACE_FIELDS, ...
    'max_face_num', 10 ... % 最多检测10张人脸
));

% ==================== 调用API ====================
handles = addLogMessage(handles, sprintf('\n===== 正在调用API... =====')); % 重定向 fprintf
options = weboptions(...
    'MediaType', 'application/json', ...
    'Timeout', 20, ...
    'CharacterEncoding', 'UTF-8');

try
    api_response = webwrite(API_URL, request_body, options);
    handles = addLogMessage(handles, 'API调用成功！'); % 重定向 fprintf

    % 保存原始API响应
    json_str = jsonencode(api_response);
    fid = fopen('api_response.json', 'w');
    fwrite(fid, json_str);
    fclose(fid);
    handles = addLogMessage(handles, 'API响应已保存: api_response.json'); % 重定向 fprintf

    api_response_struct = api_response; % 将完整的API响应赋值给输出变量

catch ME
    handles = addLogMessage(handles, sprintf('API调用失败: %s', ME.message)); % 重定向 fprintf
    % 构建错误响应结构
    api_response_struct = struct(...
        'error_code', -1, ...
        'error_msg', ME.message, ...
        'result', struct('face_num', 0) ...
    );
    return; % 错误时返回
end

% ==================== 结果解析 (保留原有的打印日志逻辑，但不影响函数返回值) ====================
handles = addLogMessage(handles, sprintf('\n===== 解析结果 =====')); % 重定向 fprintf

% 检查API错误
if isfield(api_response_struct, 'error_code') && api_response_struct.error_code ~= 0
    handles = addLogMessage(handles, sprintf('错误代码: %d', api_response_struct.error_code)); % 重定向 fprintf
    handles = addLogMessage(handles, sprintf('错误信息: %s', api_response_struct.error_msg)); % 重定向 fprintf
    handles = addLogMessage(handles, sprintf('建议: %s', get_error_suggestion(api_response_struct.error_code))); % 重定向 fprintf
% 检查人脸数量
elseif ~isfield(api_response_struct, 'result') || ...
   ~isfield(api_response_struct.result, 'face_num') || ...
   api_response_struct.result.face_num == 0
    handles = addLogMessage(handles, '未检测到人脸'); % 重定向 fprintf
else
    handles = addLogMessage(handles, sprintf('检测到 %d 张人脸', api_response_struct.result.face_num)); % 重定向 fprintf

    % 解析每张人脸信息 (此部分仅用于命令行输出调试信息，不影响函数返回值)
    face_list = api_response_struct.result.face_list;
    for i = 1:length(face_list)
        face = face_list(i);
        handles = addLogMessage(handles, sprintf('\n--- 人脸 #%d ---', i)); % 重定向 fprintf
        % ... 原有的打印详细信息逻辑 ...
        % 1. 基础信息
        if isfield(face, 'location')
            loc = face.location;
            handles = addLogMessage(handles, sprintf('位置: 左=%.1f, 上=%.1f, 宽=%.1f, 高=%.1f, 旋转=%.1f', ...
                    loc.left, loc.top, loc.width, loc.height, loc.rotation)); % 重定向 fprintf
        end

        % 2. 人口统计信息
        if isfield(face, 'age')
            handles = addLogMessage(handles, sprintf('年龄: %d岁', face.age)); % 重定向 fprintf
        end

        if isfield(face, 'gender')
            gender_map = containers.Map(...
                {'male', 'female'}, {'男性', '女性'});
            gender_type = face.gender.type;
            if isKey(gender_map, gender_type)
                gender_type = gender_map(gender_type);
            end
            handles = addLogMessage(handles, sprintf('性别: %s (%.1f%%)', gender_type, face.gender.probability*100)); % 重定向 fprintf
        end

        if isfield(face, 'race')
            race_map = containers.Map(...
                {'yellow', 'white', 'black', 'arabs'}, ...
                {'黄种人', '白种人', '黑种人', '阿拉伯人'});
            race_type = face.race.type;
            if isKey(race_map, race_type)
                race_type = race_map(race_type);
            end
            handles = addLogMessage(handles, sprintf('人种: %s (%.1f%%)', race_type, face.race.probability*100)); % 重定向 fprintf
        end

        % 3. 表情和情绪
        if isfield(face, 'expression')
            expr_map = containers.Map(...
                {'none', 'smile', 'laugh', 'anger', 'sad', 'disgust', 'fear', 'surprise', 'neutral'},...
                {'无表情', '微笑', '大笑', '愤怒', '悲伤', '厌恶', '恐惧', '惊讶', '平静'});
            expr_type = face.expression.type;
            if isKey(expr_map, expr_type)
                expr_type = expr_map(expr_type);
            end
            handles = addLogMessage(handles, sprintf('表情: %s (%.1f%%)', expr_type, face.expression.probability*100)); % 重定向 fprintf
        end

        if isfield(face, 'emotion')
            emotion_map = containers.Map(...
                {'angry', 'disgust', 'fear', 'happy', 'sad', 'surprise', 'neutral', 'pouty', 'grimace'},...
                {'愤怒', '厌恶', '恐惧', '高兴', '悲伤', '惊讶', '平静', '撅嘴', '鬼脸'});
            emotion_type = face.emotion.type;
            if isKey(emotion_map, emotion_type)
                emotion_type = emotion_map(emotion_type);
            end
            handles = addLogMessage(handles, sprintf('情绪: %s (%.1f%%)', emotion_type, face.emotion.probability*100)); % 重定向 fprintf
        end

        % 4. 穿戴物品
        if isfield(face, 'glasses')
            glasses_map = containers.Map(...
                {'none', 'common', 'sun', 'black'},...
                {'无眼镜', '普通眼镜', '太阳镜', '黑框眼镜'});
            glasses_type = face.glasses.type;
            if isKey(glasses_map, glasses_type)
                glasses_type = glasses_map(glasses_type);
            end
            handles = addLogMessage(handles, sprintf('眼镜: %s (%.1f%%)', glasses_type, face.glasses.probability*100)); % 重定向 fprintf
        end

        if isfield(face, 'mask')
            mask_map = containers.Map(...
                {'0', '1', 'none', 'wear'},...
                {'无口罩', '佩戴口罩', '无口罩', '佩戴口罩'});
            mask_type = num2str(face.mask.type);
            if isKey(mask_map, mask_type)
                mask_type = mask_map(mask_type);
            end
            handles = addLogMessage(handles, sprintf('口罩: %s (%.1f%%)', mask_type, face.mask.probability*100)); % 重定向 fprintf
        end

        if isfield(face, 'headwear')
            headwear_map = containers.Map(...
                {'0', '1', 'none', 'hat', 'helmet', 'safety_helmet'},...
                {'无头饰', '有头饰', '无头饰', '帽子', '头盔', '安全帽'});
            headwear_type = num2str(face.headwear.type);
            if isKey(headwear_map, headwear_type)
                headwear_type = headwear_map(headwear_type);
            end
            handles = addLogMessage(handles, sprintf('头饰: %s (%.1f%%)', headwear_type, face.headwear.probability*100)); % 重定向 fprintf
        end

       % 5. 人脸质量 - 修复字段不存在的问题
        if isfield(face, 'quality')
            qual = face.quality;
            % 检查字段是否存在，避免错误
            fields_to_check = {'completeness', 'illumination', 'blur'};
            field_values = [];

            for j = 1:length(fields_to_check)
                field_name = fields_to_check{j};
                if isfield(qual, field_name)
                    field_values = [field_values, qual.(field_name)];
                else
                    field_values = [field_values, NaN];
                end
            end

            handles = addLogMessage(handles, sprintf('人脸质量: 完整度=%.1f, 光照=%.1f, 模糊度=%.1f\n', ...
                    field_values(1), field_values(2), field_values(3)));

            % 如果有遮挡信息
            if isfield(qual, 'occlusion')
                occ = qual.occlusion;
                occ_fields = {'left_eye', 'right_eye', 'nose', 'mouth', 'left_cheek', 'right_cheek', 'chin_contour'};
                occ_values = [];

                for k = 1:length(occ_fields)
                    field_name = occ_fields{k};
                    if isfield(occ, field_name)
                        occ_values = [occ_values, occ.(field_name)];
                    else
                        occ_values = [occ_values, NaN];
                    end
                end

                handles = addLogMessage(handles, sprintf('  遮挡情况: 左眼=%.1f, 右眼=%.1f, 鼻子=%.1f, 嘴=%.1f, 左脸颊=%.1f, 右脸颊=%.1f, 下巴=%.1f\n', ...
                        occ_values(1), occ_values(2), occ_values(3), occ_values(4), ...
                        occ_values(5), occ_values(6), occ_values(7)));
            end
        end

        % 6. 活体检测
        if isfield(face, 'face_type')
            live_map = containers.Map(...
                {'LIVE', 'IDPHOTO', 'WATERMARK', 'SCREEN', 'MASK'},...
                {'真人', '证件照', '带水印照片', '屏幕翻拍', '面具'});
            live_type = face.face_type.type;
            if isKey(live_map, live_type)
                live_type = live_map(live_type);
            end
            handles = addLogMessage(handles, sprintf('活体检测: %s (%.1f%%)\n', live_type, face.face_type.probability*100));
        end

        % 7. 其他属性
        if isfield(face, 'beauty')
            handles = addLogMessage(handles, sprintf('颜值评分: %.1f\n', face.beauty));
        end

        if isfield(face, 'skin_status')
            skin = face.skin_status;
            handles = addLogMessage(handles, sprintf('皮肤状态: 健康度=%.1f, 色斑=%.1f, 青春痘=%.1f, 黑眼圈=%.1f\n',...
                    skin.health, skin.stain, skin.acne, skin.dark_circle));
        end
    end
end
end
% ==================== 错误处理函数 ====================
function suggestion = get_error_suggestion(error_code)
    error_map = containers.Map(...
        {0, 222202, 222203, 222204, 222205, 222300, 17, 18, 19, 100}, ...
        {'调用成功，无需处理', ...
         '图片中没有人脸', ...
         '无法解析图片，请检查格式和内容', ...
         '图片大小超过限制(最大10MB)', ...
         '图片宽高比异常(建议3:4)', ...
         '人脸检测失败', ...
         'API调用量超出限制', ...
         'QPS超出限制', ...
         '请求总量超出限制', ...
         '无效的access_token'}...
    );

    if isKey(error_map, error_code)
        suggestion = error_map(error_code);
    else
        suggestion = '未知错误，请查阅百度API文档';
    end
end

%% ================== 新增：提取文件名前缀的辅助函数 ===================
function prefix = extractBiometricPrefix(filename_input)
% extractBiometricPrefix: 从文件名中提取开头的数字前缀
%   例如: '101_1.jpg' -> '101'
%         '202_test.png' -> '202'
%         'abc_123.jpg' -> '' (如果开头不是数字)

    % Debugging: Log the type and value before conversion
    handles = guidata(gcf); % 获取当前 figure 的 handles，用于 addLogMessage
    handles = addLogMessage(handles, sprintf('extractBiometricPrefix Debug: Input type: %s, value: %s', class(filename_input), mat2str(filename_input)));
    guidata(gcf, handles); % 保存 handles 更新

    % 确保输入是字符数组
    if ~ischar(filename_input)
        if isnumeric(filename_input) && filename_input == 0
            filename = ''; % uigetfile 返回 0 时表示取消，转换为空字符串
        else
            % 尝试将任何其他类型（如 string, cell array of chars, etc.）转换为 char
            try
                filename = char(string(filename_input)); % 使用 string() 转换为 string 类型，再用 char() 转换为 char 数组
            catch
                filename = ''; % 转换失败则回退到空字符串
            end
        end
    else
        filename = filename_input;
    end

    % Debugging: Log the type and value after conversion
    handles = guidata(gcf); % 再次获取 handles
    handles = addLogMessage(handles, sprintf('extractBiometricPrefix Debug: After conversion type: %s, value: "%s"', class(filename), filename));
    %guidata(gcf, handles); % 保存 handles 更新

    prefix = ''; % 默认返回空字符串

    % 使用正则表达式匹配文件名开头的数字序列
    tokens = regexp(filename, '^(\d+)_?.*\.(?:png|jpg|jpeg|gif|tiff|tif)$', 'tokens', 'once');

    if ~isempty(tokens)
        prefix = tokens{1}; % 提取第一个匹配到的数字序列
    end
end

%% ================== 新增：指纹图像处理辅助函数 ===================
function [Im, thin_img, txy, I_gray] = processFingerprintImage(img_raw, handles)
% processFingerprintImage: 对原始指纹图像进行预处理和特征提取
%   img_raw: 原始指纹图像
%   handles: GUI handles 结构体，用于日志记录
%   返回:
%     Im: 二值化图像
%     thin_img: 细化图像
%     txy: 提取的细节点 [x, y, type]
%     I_gray: 灰度图像

    if isempty(img_raw)
        error('输入的指纹图像为空。');
    end

    % 转换为灰度图
    if ndims(img_raw) == 3
        I_gray = rgb2gray(img_raw);
    else
        I_gray = img_raw;
    end
    I = double(I_gray);

    % 执行滤波和二值化逻辑
    if size(I,1) < 10 || size(I,2) < 10
        warning('指纹图像尺寸过小 (%dx%d)，跳过部分预处理步骤。', size(I,1), size(I,2));
        Im = imbinarize(uint8(I)); % 使用简单的二值化代替
    else
        [m, n] = size(I);
        temp = (1/9)*[1 1 1;1 1 1;1 1 1]; % 均值滤波模板
        I_filtered = filter2(temp, I);
        Im = zeros(m, n);
        % 自定义二值化逻辑
        for x = 5:m-5
           for y = 5:n-5
               sum1=I_filtered(x,y-4)+I_filtered(x,y-2)+I_filtered(x,y+2)+I_filtered(x,y+4);
                sum2=I_filtered(x-2,y+4)+I_filtered(x-1,y+2)+I_filtered(x+1,y-2)+I_filtered(x+2,y-4);
                sum3=I_filtered(x-2,y+2)+I_filtered(x-4,y+4)+I_filtered(x+2,y-2)+I_filtered(x+4,y-4);
                sum4=I_filtered(x-2,y+1)+I_filtered(x-4,y+2)+I_filtered(x+2,y-1)+I_filtered(x+4,y+2);
                sum5=I_filtered(x-2,y)+I_filtered(x-4,y)+I_filtered(x+2,y)+I_filtered(x+4,y); 
                sum6=I_filtered(x-4,y-2)+I_filtered(x-2,y-1)+I_filtered(x+2,y+1)+I_filtered(x+4,y+2);
                sum7=I_filtered(x-4,y-4)+I_filtered(x-2,y-2)+I_filtered(x+2,y+2)+I_filtered(x+4,y+4);
                sum8=I_filtered(x-2,y-4)+I_filtered(x-1,y-2)+I_filtered(x+1,y+2)+I_filtered(x+2,y+4);
               sumi=[sum1,sum2,sum3,sum4,sum5,sum6,sum7,sum8];
               summax=max(sumi);
               summin=min(sumi);
               summ=sum(sumi);
               b=summ/8;
               if (summax+summin+ 4*I_filtered(x,y))> (3*summ/8)
                   sumf = summin;
               else
                   sumf = summax;
               end
               if   sumf < b
                   Im(x,y)=1; % 前景设为 1 (白色)
               end
           end
        end
         Im = ~Im; % 反转图像，使前景为 0 (黑色)，背景为 1 (白色)
    end

    % 执行开闭操作和细化
    v = Im; % 使用二值化结果
    se=strel('square',3);
    fo=imopen(v,se);
    v=imclose(fo,se); % 对图像进行开操作和闭操作
    thin_img=bwmorph(v,'thin',Inf);% 对图像进行细化

    % 提取特征点
    txy = point(thin_img); % 调用 point 函数提取特征点
end% Add this 'end' to close the main function p12022248339
