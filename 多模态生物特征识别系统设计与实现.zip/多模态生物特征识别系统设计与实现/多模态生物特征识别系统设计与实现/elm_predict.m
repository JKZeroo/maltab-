function [TestingTime, elm_predicted_label, elm_confidence, image_matched_label] = elm_predict(test_data)

%--这段 MATLAB 代码实现了极限学习机 (Extreme Learning Machine, ELM) 的预测功能，
% 同时集成了基于图像数据库 PCA 特征的相似度匹配功能。
% 输入是经过 Gabor 特征提取和 PCA 降维后的特征向量。
% 最终的识别准确度可以通过在外部调用本函数后，结合ELM预测结果、置信度和图像匹配结果进行决策来提高。

% Usage: [TestingTime, elm_predicted_label, elm_confidence, image_matched_label] = elm_predict(test_data)
%
% Input:
% test_data             - Testing data matrix. Expected to be 1xN matrix for a single sample,
%                         where N is 1 + NumberOfFeatures. The first column is a placeholder (e.g., 0),
%                         and the rest are the input features for ELM, which are assumed to be
%                         the PCA-reduced Gabor features (e.g., 196 dimensions).
%                         If test_data has multiple rows, each row is treated as a separate sample.
%
% Output:
% TestingTime           - Time (seconds) spent on calculating ELM output for ALL testing data in test_data.
% elm_predicted_label   - Predicted label(s) for each testing data sample based on ELM output.
%                         For classification, this is the predicted class label. For regression, this is the predicted value.
% elm_confidence        - Confidence score(s) for the ELM predicted label(s).
%                         For classification, this is the softmax probability of the predicted class.
%                         For regression, set to NaN or a placeholder.
% image_matched_label   - Predicted label(s) based on image similarity matching of the input
%                         PCA features against the database PCA features stored in S.mat.
%                         If image matching is successful, returns the matched label for each input sample.
%                         If S.mat is not found, or matching fails, returns NaN for that sample.

% 修改说明：
% 1. 输入参数 dt 被移除，图像匹配直接使用 test_data 中的 PCA 特征。
% 2. ELM 预测基于 test_data 中的特征部分。
% 3. 图像匹配基于 test_data 中的特征部分与 S.mat 中的 PCA 特征进行距离计算。
% 4. 函数同时返回 ELM 预测结果和图像相似度匹配结果，供外部进行融合决策。
% 5. 增强鲁棒性，增加错误和警告提示。
% 6. 图像匹配使用 PCA 特征向量之间的欧氏距离。

REGRESSION = 0;
CLASSIFIER = 1;
% Initialize outputs to default/placeholder values
elm_predicted_label = [];
elm_confidence = [];
image_matched_label = NaN; % Default value for image matching result(s)
TestingTime = 0; % Initialize testing time

%%%%%%%%%%% 加载测试数据
% test_data is assumed to be a matrix where the first column is placeholder/label and rest are features
if nargin < 1 || isempty(test_data) || ~ismatrix(test_data) || size(test_data, 2) < 2
    error('输入 test_data 无效或格式不正确。需要至少两列 (占位标签 + 特征)。');
end

TV.T = test_data(:,1)';  % Placeholder labels (1 x NumberofTestingData)
TV.P = test_data(:,2:size(test_data,2))'; % Features (NumberofFeatures x NumberofTestingData)

NumberofTestingData = size(TV.P,2);
NumberofFeatures = size(TV.P, 1); % Number of input features after transposing

%%%%%%%%%%% 加载预训练模型
% Load the trained ELM model (InputWeight, BiasofHiddenNeurons, OutputWeight, Elm_Type, NumberofOutputNeurons, ActivationFunction, label)
% Ensure elm_model.mat is in current path or specified path
model_filepath = fullfile(pwd, 'elm_model.mat');
try
    loaded_model = load(model_filepath, 'InputWeight', 'BiasofHiddenNeurons', ...
        'OutputWeight', 'ActivationFunction', 'Elm_Type', 'label', 'NumberofOutputNeurons');

    % Check if all required variables were loaded
    required_vars_strict = {'InputWeight', 'BiasofHiddenNeurons', 'OutputWeight', ...
                            'ActivationFunction', 'Elm_Type', 'NumberofOutputNeurons'};
    missing_vars_strict = setdiff(required_vars_strict, fields(loaded_model));
    if ~isempty(missing_vars_strict)
        error('ELM模型文件 "%s" 加载失败，缺少以下关键变量: %s', model_filepath, strjoin(missing_vars_strict, ', '));
    end

    % Assign loaded variables
    InputWeight = loaded_model.InputWeight;
    BiasofHiddenNeurons = loaded_model.BiasofHiddenNeurons;
    OutputWeight = loaded_model.OutputWeight;
    ActivationFunction = loaded_model.ActivationFunction;
    Elm_Type = loaded_model.Elm_Type;
    NumberofOutputNeurons = loaded_model.NumberofOutputNeurons;

    % Handle optional label variable
    if isfield(loaded_model, 'label')
        label = loaded_model.label;
        if size(label, 2) ~= NumberofOutputNeurons
             warning('ELM模型文件 "%s" 中标签对照表 "label" 的数量 (%d) 与输出神经元数量 (%d) 不匹配。分类预测结果可能基于神经元索引而非实际标签值。', model_filepath, size(label, 2), NumberofOutputNeurons);
             has_label_map = false;
        else
             has_label_map = true;
        end
    else
        warning('ELM模型文件 "%s" 中未包含标签对照表 "label"。分类预测结果将是输出神经元的索引而非实际标签值。', model_filepath);
        has_label_map = false;
        % Create a dummy label map using indices if missing, helps in mapping
        label = 1:NumberofOutputNeurons; % Example: If 7 output neurons, labels become 1, 2, ..., 7
    end


catch ME
    error('ELM模型文件 "%s" 加载失败: %s', model_filepath, ME.message);
end

% Validate model parameters against input data features (excluding the placeholder label column)
% Check input feature dimension
if size(InputWeight, 2) ~= NumberofFeatures
    error('ELM模型输入权重维度 (%d) 与测试数据特征数量 (%d) 不匹配。请确保您提供给 ELM 的特征维数与训练模型时一致。', size(InputWeight, 2), NumberofFeatures);
end

% Check hidden layer consistency
if size(BiasofHiddenNeurons, 1) ~= size(InputWeight, 1)
     error('ELM模型偏置向量数量 (%d) 与输入权重行数 (%d) 不匹配 (隐藏层神经元数量不一致)。', size(BiasofHiddenNeurons, 1), size(InputWeight, 1));
end

% Check output layer consistency
if size(OutputWeight, 1) ~= size(InputWeight, 1)
     error('ELM模型输出权重行数 (%d) 与输入权重行数 (%d) 不匹配 (连接到隐藏层神经元数量不一致)。', size(OutputWeight, 1), size(InputWeight, 1));
end
if size(OutputWeight, 2) ~= NumberofOutputNeurons
     error('ELM模型输出权重列数 (%d) 与模型定义的输出神经元数量 (%d) 不匹配。', size(OutputWeight, 2), NumberofOutputNeurons);
end


%%%%%%%%%%% 计算ELM输出
start_time_test = cputime;
% TV.P contains the features (NumberofFeatures x NumberofTestingData)
tempH_test = InputWeight * TV.P;

ind = ones(1, NumberofTestingData);
BiasMatrix = BiasofHiddenNeurons(:, ind); % Extend bias matrix to match NumberofTestingData
if size(BiasMatrix, 1) ~= size(tempH_test, 1)
    error('偏置矩阵维度 (%d) 与输入到激活函数的矩阵维度 (%d) 不匹配。', size(BiasMatrix, 1), size(tempH_test, 1));
end
tempH_test = tempH_test + BiasMatrix;

% 应用激活函数
switch lower(ActivationFunction)
    case {'sig','sigmoid'}
        tempH_test(tempH_test > 30) = 30;
        tempH_test(tempH_test < -30) = -30;
        H_test = 1 ./ (1 + exp(-tempH_test));
    case {'sin','sine'}
        H_test = sin(tempH_test);
    case {'hardlim'}
        H_test = hardlim(tempH_test);
    case {'relu'}
        H_test = max(0, tempH_test);
    otherwise
        error('不支持的激活函数: %s', ActivationFunction);
end

if size(H_test, 1) ~= size(OutputWeight, 1)
    error('激活函数输出维度 (%d) 与输出权重行数 (%d) 不匹配。', size(H_test, 1), size(OutputWeight, 1));
end

TY = (H_test' * OutputWeight)';  % ELM原始输出 (NumberofOutputNeurons x NumberofTestingData)
TestingTime = cputime - start_time_test;

%%%%%%%%%%% 处理 ELM 预测结果
elm_predicted_label = zeros(1, NumberofTestingData);
elm_confidence = zeros(1, NumberofTestingData); % Default confidence

if Elm_Type == CLASSIFIER
    % Check if there are output neurons for classification
    if NumberofOutputNeurons <= 0
         warning('ELM模型输出神经元数量为零。无法进行分类预测。');
         elm_predicted_label = NaN(1, NumberofTestingData);
         elm_confidence = NaN(1, NumberofTestingData);
    else % Only proceed if there are output neurons
        for i = 1:NumberofTestingData
            % 获取当前样本的输出分数
            scores = TY(:, i);

            % 计算softmax置信度
            % Ensure scores are valid numeric values for softmax
            if ~isnumeric(scores) || any(isnan(scores)) || any(isinf(scores)) || length(scores) < 1 % Need at least one score
                 warning('样本 %d 的 ELM 输出分数为无效值 (Inf/NaN)。无法计算softmax。', i);
                 elm_predicted_label(i) = NaN;
                 elm_confidence(i) = NaN;
            else
                % Subtract max for numerical stability before exp
                max_score = max(scores);
                % Handle case where max_score is -Inf or NaN
                if isfinite(max_score)
                     exp_scores = exp(scores - max_score);
                     sum_exp_scores = sum(exp_scores);
                     if sum_exp_scores <= eps % Avoid division by near-zero or zero sum
                          probs = zeros(size(scores)); % Cannot compute meaningful probabilities
                          % warning('样本 %d 的softmax指数和过小或为零。置信度设为零。', i);
                     else
                         probs = exp_scores / sum_exp_scores; % Softmax probabilities
                     end
                else % max_score is -Inf or NaN
                    probs = zeros(size(scores)); % Cannot compute meaningful probabilities
                     warning('样本 %d 的最大ELM输出分数为无限大或NaN。无法计算softmax。', i);
                end

                % Find the class with the maximum probability
                [max_prob, max_idx] = max(probs); % max_idx is the index of the output neuron/class (1 to NumberofOutputNeurons)

                % Store the result - Map index to actual label value using the loaded 'label' array
                % Ensure max_idx is a valid index for the 'label' array
                if max_idx >= 1 && max_idx <= length(label)
                     elm_predicted_label(i) = label(max_idx);
                     elm_confidence(i) = max_prob; % Softmax probability as confidence
                else
                     warning('样本 %d 的 ELM 预测索引 %d (从max(probs)获得) 无效或超出标签对照表范围 (%d)。无法确定预测标签。', i, max_idx, length(label));
                     elm_predicted_label(i) = NaN; % Indicate prediction failed
                     elm_confidence(i) = NaN;
                end
            end
        end
    end


elseif Elm_Type == REGRESSION
    elm_predicted_label = TY; % For regression, output is the prediction value
    % Regression doesn't have probability confidence. Use NaN.
    elm_confidence = ones(1, NumberofTestingData) * NaN;


else
    error('未知或不支持的 ELM 类型: %d', Elm_Type); % Handle unexpected Elm_Type
end


%%%%%%%%%%% 图像相似度匹配部分 (使用输入 PCA 特征与数据库 PCA 特征对比)

% Default result if image matching is not possible
image_matched_label = NaN(1, NumberofTestingData); % Initialize for all samples

% Load the image database S.mat (containing PCA features S(i).G)
% Ensure S.mat is in current path or specified path
S_filepath = fullfile(pwd, 'S.mat');
try
    if exist(S_filepath, 'file')
        loaded_S = load(S_filepath, 'S'); % Assuming S.mat contains a struct array 'S'
         if isfield(loaded_S, 'S') && isstruct(loaded_S.S) && ~isempty(loaded_S.S)
             S = loaded_S.S; % Assign loaded struct array
             sprintf('成功加载图像数据库 S.mat，包含 %d 张图片信息和PCA特征。\n', length(S));
            
           
             has_image_database = true;
         else
             warning('S.mat 文件已加载，但变量 ''S'' 不是一个非空结构体数组。无法执行图像相似度匹配。');
             S = []; % Treat as empty database
             has_image_database = false;
         end
    else
        warning('图像数据库文件 S.mat 未找到在 %s。将跳过图像相似度匹配。', S_filepath);
        S = []; % Treat as empty database
        has_image_database = false;
    end

catch ME
    warning('加载图像数据库 S.mat 时发生意外错误: %s。无法执行图像相似度匹配。', ME.message);
    S = [];
    has_image_database = false;
end


% Proceed with image matching only if database loaded and input features are valid
% Input features are TV.P (NumberofFeatures x NumberofTestingData)
if has_image_database && isnumeric(TV.P) && ~any(isnan(TV.P(:))) && all(isfinite(TV.P(:)))

    % Iterate through each test sample
    for i = 1:NumberofTestingData
        % Get the PCA feature vector for the current test sample
        current_test_pca_feature = TV.P(:, i); % Column vector (NumberofFeatures x 1)

        % Ensure the feature vector is valid for comparison
        if ~isnumeric(current_test_pca_feature) || any(isnan(current_test_pca_feature(:))) || any(isinf(current_test_pca_feature(:))) || isempty(current_test_pca_feature)
            warning('样本 %d 的输入 PCA 特征无效或为空。无法进行图像匹配。', i);
            image_matched_label(i) = NaN; % Mark as failed for this sample
            continue; % Skip to next sample
        end
        
        % *** Debug Print: Input Feature Size for Image Matching ***
        % fprintf('样本 %d 输入 PCA 特征大小用于图像匹配: [%d, %d]\n', i, size(current_test_pca_feature, 1), size(current_test_pca_feature, 2));

        dis = inf(1, length(S)); % Initialize distances for this sample to infinity
        valid_comparisons = 0;

        % Loop through the images in the database S
        for j = 1 : length(S)
             % Ensure the database entry has a PCA feature field 'G' and it's valid
             if isfield(S(j), 'G') && ~isempty(S(j).G) && isnumeric(S(j).G) && ~any(isnan(S(j).G(:))) && all(isfinite(S(j).G(:)))
                  % Ensure database PCA feature size matches input PCA feature size
                 % S(j).G is assumed to be a row vector (1 x NumberofFeatures) as saved by PcaDataBase
                 % current_test_pca_feature is a column vector (NumberofFeatures x 1)
                 % Need to compare vectors of the same orientation, e.g., row vs row or column vs column
                 % Let's assume S(j).G is a row vector as per typical matrix structure after PCA transform
                 % And current_test_pca_feature needs to be a row vector for consistent comparison
                 
                 % Ensure S(j).G is a row vector explicitly for comparison
                 db_pca_feature_row = S(j).G(:)'; % Force to row vector
                 
                 % Ensure input feature is a row vector for comparison
                 input_pca_feature_row = current_test_pca_feature(:)'; % Force to row vector


                 % Check if number of features match
                 if numel(db_pca_feature_row) == numel(input_pca_feature_row)
                      % Calculate distance (Euclidean distance in PCA space)
                     dis(j) = norm(double(db_pca_feature_row) - double(input_pca_feature_row));
                     valid_comparisons = valid_comparisons + 1;
                 else
                      % Handle size mismatch in PCA features - this indicates a fundamental issue
                     warning('样本 %d 与数据库条目 %d (%s) 的 PCA 特征维度不匹配 (%d vs %d)。跳过比较。', ...
                         i, j, S(j).filename, numel(input_pca_feature_row), numel(db_pca_feature_row));
                     % dis(j) remains inf
                 end
             else
                 % Database entry is missing 'G' field or feature is invalid
                 % warning('S.mat 中条目 %d 缺少有效 PCA 特征。跳过比较。', j);
                 % dis(j) remains inf
             end
        end % end loop j (database entries)

        % Determine the matched label for the current sample (i) if successful comparisons were made
        if valid_comparisons > 0 && any(isfinite(dis)) % Check if any finite distances were recorded for this sample
            % Find the index of the most similar image (minimum distance)
            [min_dist, ind] = min(dis);

            if isfinite(min_dist) % Ensure the minimum distance is valid
                 % Get the filename from the most similar image entry in S
                if ind > 0 && ind <= length(S) && isfield(S(ind), 'filename') && ~isempty(S(ind).filename)
                     temp_filename = S(ind).filename;

                    % Determine the label based on the filename prefix (Mapping needs verification)
                    % This mapping assumes prefixes like 'NE', 'HA', etc. correspond to specific label numbers.
                    % VERIFY this mapping (prefix to label number) against your ELM 'label' array and data.
                    % Example mapping based on common emotion datasets and your original code:
                    if contains(temp_filename, 'NE', 'IgnoreCase', true)
                        image_matched_label(i) = 1; % Neutral
                    elseif contains(temp_filename, 'HA', 'IgnoreCase', true)
                        image_matched_label(i) = 2; % Happy
                    elseif contains(temp_filename, 'SA', 'IgnoreCase', true)
                        image_matched_label(i) = 3; % Sad
                    elseif contains(temp_filename, 'SU', 'IgnoreCase', true)
                        image_matched_label(i) = 4; % Surprise
                    elseif contains(temp_filename, 'AN', 'IgnoreCase', true)
                        image_matched_label(i) = 5; % Anger
                    elseif contains(temp_filename, 'DI', 'IgnoreCase', true)
                        image_matched_label(i) = 6; % Disgust
                    elseif contains(temp_filename, 'FE', 'IgnoreCase', true)
                        image_matched_label(i) = 7; % Fear
                    else
                        % If filename prefix doesn't match expected patterns
                        image_matched_label(i) = NaN;
                         warning('数据库图像文件名 "%s" 不匹配预期的标签模式。无法确定图像匹配标签。', temp_filename);
                    end
                    fprintf('样本 %d 图像匹配成功 (基于 PCA 特征)，最相似图片 "%s" (距离 %.4f)，匹配标签: %f。\n', i, temp_filename, min_dist, image_matched_label(i));

                else
                    warning('样本 %d 找到最小距离的索引 %d 无效或对应的文件名缺失。无法确定图像匹配标签。', i, ind);
                    image_matched_label(i) = NaN;
                end
            else
                 warning('样本 %d 计算出的最小图像距离无效。无法确定匹配的标签。', i);
                 image_matched_label(i) = NaN;
            end
        else
             warning('样本 %d 未找到有效的数据库 PCA 特征进行对比或所有对比均失败。无法执行图像匹配。', i);
             image_matched_label(i) = NaN;
        end % end if valid_comparisons > 0

    end % end loop i (test samples)

else % Image database not loaded, or input features are invalid
    warning('图像数据库未加载或输入 PCA 特征无效。跳过图像相似度匹配。');
    image_matched_label = NaN(1, NumberofTestingData); % Mark all samples as failed
end


% The function ends here, returning the calculated values.
% Fusion/decision logic should be implemented by the caller (in processEmotion).

% Optional: Save results - uncomment and adjust if needed
% if NumberofTestingData == 1 % Only save if processing a single sample
%    save(fullfile(pwd, 'elm_output.mat'), 'elm_predicted_label', 'elm_confidence', 'image_matched_label', 'TestingTime');
% end

end