%% PrepareDatabaseAndTrainData.m
% 该脚本实现了从原始图像到构建 ELM 训练数据和图像匹配数据库的完整预处理流程。
% 流程包括：读取图片列表 -> Gabor 特征提取 -> 基于 Gabor 特征训练 PCA 模型 ->
% 对所有图片应用 PCA 降维 -> 生成 ELM 训练数据和图像数据库 (S.mat)。

clc; clear all; close all;

%% 配置参数
dataDir = fullfile(pwd, 'Database'); % 原始图片数据库文件夹
listFile = fullfile(pwd, 'Database', 'list.txt'); % 图片文件名列表文件
outputDir = pwd; % 输出文件 (model.mat, S.mat, train_data.mat) 保存目录

% Gabor 滤波器参数 (需要与预测阶段使用的参数一致)
gabor_Sx = 2;
gabor_Sy = 4;
gabor_f = 16;
gabor_theta = pi/3; % 或根据需要调整，例如 [0, pi/6, pi/3, pi/2, 2*pi/3, 5*pi/6] 等多方向
% 如果 gaborfilter 函数接受多个 theta 值并返回所有方向的特征，这里也应对应。
% 如果 gaborfilter 只处理一个 theta，并且您需要多方向特征，您可能需要多次调用 gaborfilter
% 并合并结果。请根据您的 gaborfilter 实现进行调整。
% 这里的脚本假设 gaborfilter(double(I_resized), gabor_Sx, gabor_Sy, gabor_f, gabor_theta)
% 返回一个能展平为单行向量的特征输出。

% 图像预处理尺寸 (需要与预测阶段使用的尺寸一致)
img_resize_dim = [50 50]; % [height, width]

% PCA 降维维度 (需要与 ELM 模型期望的输入特征数量一致)
pca_output_dim = 196;

% 情绪标签映射 (根据您的文件名前缀和对应的标签值进行调整)
% 确保这里的映射与您 ELM 训练和预测中使用的标签值一致
% 根据您提供的 list.txt，情绪缩写是文件名中 '.' 分割的第二部分的前两个字符。
emotion_label_map = containers.Map({'NE', 'HA', 'SA', 'SU', 'AN', 'DI', 'FE'}, {1, 2, 3, 4, 5, 6, 7});


%% 1. 读取图片列表并构建初始 S 结构体
fprintf('1. 读取图片列表 %s...\n', listFile);
S = []; % 初始化 S 结构体数组
try
    fid = fopen(listFile, 'r');
    if fid == -1
        error('无法打开文件 %s。请检查路径或文件权限。', listFile);
    end

    while ~feof(fid)
        tline = fgetl(fid);
        if ischar(tline) && ~isempty(tline)
            % 假设图片名在每行最后一个空格后，或就是整行
            % 您的 list.txt 看起来是 dir 命令的输出格式，文件名在最后
            ind = find(tline == ' ', 1, 'last'); % 找到最后一个空格
            if ~isempty(ind)
                filename = strtrim(tline(ind+1:end));
            else
                % 如果没有空格，假设整行就是文件名
                filename = strtrim(tline);
            end

            if ~isempty(filename)
                % 检查文件是否存在
                fullImagePath = fullfile(dataDir, filename);
                if exist(fullImagePath, 'file')
                    s.filename = filename;

                    % === 修正后的标签提取逻辑 (只取文件名第二个部分的头两个字符) ===
                    % 尝试从文件名提取标签
                    parts = strsplit(filename, '.'); % 以 '.' 分割文件名
                    % 确保分割后至少有两部分，并且第二部分至少有两个字符
                    if length(parts) >= 2 && length(parts{2}) >= 2
                         % 取分割后的第二个部分的头两个字符作为情绪前缀
                        emotion_prefix = upper(parts{2}(1:2));
                        if isKey(emotion_label_map, emotion_prefix)
                            s.label = emotion_label_map(emotion_prefix);
                        else
                            s.label = NaN; % 无法确定标签
                            warning('文件名 "%s" 提取到的情绪前缀 "%s" 未在标签映射中找到。对应样本将标记为NaN标签。', filename, emotion_prefix);
                        end
                    else
                         s.label = NaN; % 无法确定标签 (文件名格式不符合预期)
                         warning('文件名 "%s" 格式不符合预期 (没有 "." 分割或第二部分少于两个字符)。无法提取情绪标签。对应样本将标记为NaN标签。', filename);
                    end
                    % === 修正结束 ===

                    % 将当前样本结构体追加到 S 数组
                    if isempty(S)
                        S = s; % 第一次添加样本
                    else
                        S(end+1) = s; % 后续添加样本
                    end

                else
                    warning('文件 %s 不存在。跳过。', fullImagePath);
                end
            end
        end
    end
    fclose(fid);
catch ME
    if fid ~= -1
        fclose(fid); % Ensure file is closed in case of error
    end
    rethrow(ME); % Rethrow the error
end

num_samples = length(S);
if num_samples == 0
    error('未找到任何有效的图片文件。请检查数据目录、list.txt 文件内容和文件路径。');
end
fprintf('成功读取 %d 个图片文件名列表。\n', num_samples);


%% 2. 提取所有图片的 Gabor 特征
fprintf('2. 提取所有图片的 Gabor 特征...\n');
% 存储所有 Gabor 特征的矩阵，每一行是一个样本的展平特征
all_gabor_features = [];
valid_samples_indices = []; % 记录成功提取特征的样本在原始 S 结构体中的索引
sample_labels = []; % 存储对应样本的标签

h_gabor = waitbar(0,'提取 Gabor 特征中...', 'Name', 'Gabor Feature Extraction');
for i = 1:num_samples
    waitbar(i/num_samples, h_gabor, sprintf('处理图片 %d/%d: %s', i, num_samples, S(i).filename));

    fullImagePath = fullfile(dataDir, S(i).filename);

    try
        Img = imread(fullImagePath);
        % 转换为灰度图
        if ndims(Img) == 3
            I = rgb2gray(Img);
        else
            I = Img;
        end

        % 统一预处理尺寸
        I_resized = imresize(I, img_resize_dim, 'bilinear');

        % 提取 Gabor 特征 (确保 gaborfilter 是独立的函数文件并可访问)
        % gaborfilter 需要 double 类型的输入
        % 这里的实现假设 gaborfilter 返回一个可以直接展平的单维特征向量
        % 如果您的 gaborfilter 返回多个方向的特征或不同形式，需要在此处调整合并逻辑
        [~, gabout] = gaborfilter(double(I_resized), gabor_Sx, gabor_Sy, gabor_f, gabor_theta);

        % 展平 Gabor 特征为向量
        gab_flat = gabout(:)'; % (1 x height*width*num_orientations) 或 (1 x height*width)

        % 收集特征和标签
        all_gabor_features = [all_gabor_features; gab_flat];
        valid_samples_indices = [valid_samples_indices, i];
        sample_labels = [sample_labels; S(i).label]; % 收集标签

    catch ME
        warning('处理图片 "%s" 时提取 Gabor 特征失败: %s。跳过该样本。', S(i).filename, ME.message);
        % 该样本将不会包含在 all_gabor_features 和后续的 PCA/ELM 数据中
    end
end
delete(h_gabor);

num_valid_samples = size(all_gabor_features, 1);
if num_valid_samples == 0
    error('未能成功提取任何样本的 Gabor 特征。请检查图片文件和 gaborfilter 函数。');
end
fprintf('成功提取 %d 个样本的 Gabor 特征 (维度: %d)。\n', num_valid_samples, size(all_gabor_features, 2));


%% 3. 训练 PCA 模型 (基于 Gabor 特征)
fprintf('3. 训练 PCA 模型...\n');

% 检查 Gabor 特征维度是否符合预期 resize 后的尺寸
% 注意：如果 gaborfilter 输出是多通道的（如多方向），这里计算的 expected_gabor_dim 需要乘以通道数
expected_gabor_dim = img_resize_dim(1) * img_resize_dim(2);
% if size(all_gabor_features, 2) != expected_gabor_dim
%     % 这条检查现在不完全准确，因为 Gabor 特征维度可能取决于 gaborfilter 的输出
%     % 例如，如果 gaborfilter 对每个方向输出一个图像，并且 theta 是一个向量，
%     % 展平的特征维度会是 height*width*length(theta)
%     % 我们将依赖 cov 函数来处理实际维度
%     warning('提取的 Gabor 特征维度 (%d) 可能与预期 resize 后尺寸 (%d*%d=%d) 不直接匹配，具体取决于 gaborfilter 实现。', ...
%         size(all_gabor_features, 2), img_resize_dim(1), img_resize_dim(2), expected_gabor_dim);
% end


% 计算均值
samplemean = mean(all_gabor_features, 1); % 均值向量 (1 x Gabor特征维度)

% 中心化数据
centered_gabor_features = all_gabor_features - samplemean; % (num_valid_samples x Gabor特征维度)

% 计算协方差矩阵
% sigma = cov(all_gabor_features); % 使用原始数据计算协方差
sigma = centered_gabor_features' * centered_gabor_features / (num_valid_samples - 1); % 使用中心化数据计算协方差 (更直接)

fprintf('计算协方差矩阵 (%d x %d)...\n', size(sigma, 1), size(sigma, 2));

% 检查协方差矩阵是否有效 (避免维度过小或样本数不足导致错误)
if isempty(sigma) || any(isnan(sigma(:))) || any(isinf(sigma(:))) || size(sigma, 1) == 0
     error('协方差矩阵计算失败或包含无效值。请检查 Gabor 特征提取是否正确，并确保至少有两个样本。');
end

% 检查协方差矩阵是否是正方形（应为 Gabor 特征维度 x Gabor 特征维度）
if size(sigma, 1) ~= size(sigma, 2) || size(sigma, 1) ~= size(all_gabor_features, 2)
    error('协方差矩阵维度与 Gabor 特征维度不匹配。请检查计算过程。');
end


% 进行特征值分解
[v, d] = eig(sigma); % v 是特征向量，d 是特征值矩阵

% 按特征值降序排序特征向量 (主成分)
d_diag = diag(d);
[d_sorted, sort_indices] = sort(d_diag, 'descend');
v_sorted = v(:, sort_indices); % v_sorted 的列是按对应特征值大小排序的特征向量

% 提取变换矩阵 (取前 pca_output_dim 个主成分)
if pca_output_dim > size(v_sorted, 2)
    warning('PCA 降维维度 (%d) 大于 Gabor 特征维度 (%d)。将使用所有维度。', pca_output_dim, size(v_sorted, 2));
    pca_output_dim = size(v_sorted, 2);
end
base = v_sorted(:, 1:pca_output_dim); % PCA 变换矩阵 (Gabor特征维度 x pca_output_dim)

fprintf('PCA 模型训练完成。降维至 %d 维。\n', pca_output_dim);


%% 4. 对所有有效样本的 Gabor 特征应用 PCA 降维
fprintf('4. 对样本 Gabor 特征应用 PCA 降维...\n');
% 使用训练好的 PCA 模型对所有样本的 Gabor 特征进行降维
% 降维后的特征矩阵 (num_valid_samples x pca_output_dim)
pca_features_all_samples = centered_gabor_features * base;


%% 5. 生成 ELM 训练数据 (标签 + PCA 特征)
fprintf('5. 生成 ELM 训练数据...\n');
% 检查标签和特征数量是否匹配
if size(sample_labels, 1) ~= num_valid_samples || size(pca_features_all_samples, 1) ~= num_valid_samples
    error('样本标签数量 (%d) 与提取的 PCA 特征数量 (%d) 不匹配。这是一个内部逻辑错误。', size(sample_labels, 1), num_valid_samples);
end

% 移除标签为 NaN 的样本 (这些样本无法用于有监督训练)
valid_label_indices = ~isnan(sample_labels);
train_data_features = pca_features_all_samples(valid_label_indices, :);
train_data_labels = sample_labels(valid_label_indices);

if isempty(train_data_features)
     error('没有样本具有有效标签。无法生成 ELM 训练数据。请检查文件名格式和 emotion_label_map 配置是否正确。');
end

% 构建 ELM 训练数据矩阵 (第一列是标签，其余是特征)
% ELM 训练函数期望标签是第一列
train_data = [train_data_labels, train_data_features]; % (NumTrainingSamples x 1+pca_output_dim)

fprintf('生成 ELM 训练数据完成。训练样本数: %d, 维度: %d。\n', size(train_data, 1), size(train_data, 2));


%% 6. 更新 S 结构体，存储数据库图片的 PCA 特征
fprintf('6. 更新 S.mat，存储数据库图片 PCA 特征...\n');
% 遍历原始 S 结构体 (包含所有文件名)，将降维后的特征存入对应的条目
% 需要根据 valid_samples_indices 将 pca_features_all_samples 映射回原始 S 结构体
% all_gabor_features 的行对应 valid_samples_indices 里的原始 S 索引
% 因此 pca_features_all_samples 的行顺序也对应 valid_samples_indices 里的原始 S 索引

S_updated = S; % 创建一个 S 的副本进行修改
pca_features_row_idx = 1; % 用于跟踪 pca_features_all_samples 中的当前行索引

for i = 1:num_samples
    % 如果这个样本是成功提取特征的有效样本 (它的原始索引 i 在 valid_samples_indices 中)
    if ismember(i, valid_samples_indices)
        % 将对应的 PCA 特征向量存入 S_updated 的 G 字段
        % pca_features_all_samples 的第 pca_features_row_idx 行对应 S(i)
        S_updated(i).G = pca_features_all_samples(pca_features_row_idx, :); % (1 x pca_output_dim)
        pca_features_row_idx = pca_features_row_idx + 1; % 移动到 pca_features_all_samples 的下一行
    else
        % 对于未成功处理的样本，其 G 字段设为 NaN
        S_updated(i).G = NaN(1, pca_output_dim); % 设为 NaN 向量，维度与预期一致
    end
end

% 覆盖原始 S 结构体
S = S_updated;
fprintf('更新 S.mat 结构体完成，添加了 PCA 特征字段。\n');


%% 7. 保存生成的文件
fprintf('7. 保存生成的文件到 %s...\n', outputDir);
% 保存 PCA 模型
save(fullfile(outputDir, 'model.mat'), 'base', 'samplemean');
fprintf('保存 PCA 模型到 model.mat。\n');

% 保存更新后的 S 结构体 (包含 PCA 特征 G 字段)
save(fullfile(outputDir, 'S.mat'), 'S');
fprintf('保存图像数据库信息 (包含 PCA 特征) 到 S.mat。\n');

% 保存 ELM 训练数据
save(fullfile(outputDir, 'train_data.mat'), 'train_data');
fprintf('保存 ELM 训练数据到 train_data.mat。\n');

fprintf('数据准备和特征提取流程完成！\n');
